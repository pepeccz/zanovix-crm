// Internal-side pages: Dashboard, Pipeline (kanban), Clients list,
// Client 360 detail, Service detail, Billing, Calendar, Team.

const { useState: useStateInt, useMemo: useMemoInt } = React;
const { fmtMoney, fmtDate, fmtDateShort, byId, clientOf, userOf, serviceOf } = window.helpers;
const D = window.DATA;

/* ================================================================
   DASHBOARD
   ================================================================ */
function DashboardPage() {
  const t = useT();
  const { lang } = useApp();

  const totalMRR = D.clients.reduce((s, c) => s + (c.mrr || 0), 0);
  const activePipeline = D.clients.filter(c => !["active","lost"].includes(c.stage)).length;
  const proposalsOut = D.clients.filter(c => c.stage === "proposal_sent").length;
  const diagsRunning = D.services.filter(s => s.type === "assessment" && s.state !== "completed").length;

  const recentInvoices = [...D.invoices]
    .filter(i => i.issued)
    .sort((a,b) => (b.issued || "").localeCompare(a.issued || ""))
    .slice(0, 5);

  const upcoming = [...D.events]
    .sort((a,b) => (a.date+a.time).localeCompare(b.date+b.time))
    .slice(0, 4);

  // Pipeline mini-funnel
  const stageCounts = D.stages.map(st => ({
    ...st,
    count: D.clients.filter(c => c.stage === st.id).length,
    value: D.clients.filter(c => c.stage === st.id).reduce((sum, c) => {
      // estimate value: mrr*12 for active, else a placeholder per stage
      const est = { lead: 5000, discovery_scheduled: 12000, discovery_done: 22000, proposal_sent: 38000, active: (c.mrr||0)*12 + 25000 }[st.id] || 0;
      return sum + est;
    }, 0),
  }));

  // Action queue
  const actions = [
    { kind: "overdue", text: lang === "es" ? "Factura vencida · Bodegas Linares" : "Overdue invoice · Bodegas Linares", sub: "INV-2026-035 · 5.200 €", href: "#/admin/billing" },
    { kind: "review",  text: lang === "es" ? "Revisión hito 3 · Naviera SAP" : "Milestone 3 review · Naviera SAP", sub: lang === "es" ? "Hoy · 16:00 con Clara y Álex" : "Today · 16:00 with Clara & Álex", href: "#/admin/services/s-navmed-2" },
    { kind: "proposal",text: lang === "es" ? "Propuesta pendiente de firma · Despacho Cruz" : "Proposal awaiting signature · Despacho Cruz", sub: lang === "es" ? "Enviada hace 6 días" : "Sent 6 days ago", href: "#/admin/clients/c-despacho-cruz" },
    { kind: "discovery", text: lang === "es" ? "Discovery mañana · Logística Ríos" : "Discovery tomorrow · Logística Ríos", sub: lang === "es" ? "Sin agenda preparada todavía" : "No agenda prepared yet", href: "#/admin/calendar" },
  ];

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "panel general" : "overview"}
        title={lang === "es"
          ? `Hoy en <em style="font-style:italic;font-weight:300;color:#2E8169">Zanovix</em>`
          : `Today at <em style="font-style:italic;font-weight:300;color:#2E8169">Zanovix</em>`}
        lede={t("page.dashboard.lede")}
        right={
          <>
            <Btn kind="ghost" icon="filter" size="sm">{t("common.this_week")}</Btn>
            <Btn kind="accent" icon="plus" size="sm">{t("shell.new")}</Btn>
          </>
        }
      />

      {/* KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)",
        borderBottom: "1px solid rgba(31,42,38,0.14)", padding: "0 16px" }}>
        <KPI label={t("kpi.pipeline")}     value={activePipeline} delta={"+2"} footnote={lang === "es" ? "Dos leads nuevos esta semana." : "Two new leads this week."}/>
        <KPI label={t("kpi.mrr")}          value={fmtMoney(totalMRR, lang)} delta={"+580 €"} footnote={lang === "es" ? "Bodegas Linares entró en mantenimiento." : "Bodegas Linares began maintenance."}/>
        <KPI label={t("kpi.proposals")}    value={proposalsOut} delta="" footnote={lang === "es" ? "Una propuesta a punto de cumplir 7 días." : "One proposal nearly seven days old."}/>
        <KPI label={t("kpi.diagnostics")}  value={diagsRunning} delta="" footnote={lang === "es" ? "Un diagnóstico arranca el martes." : "A new diagnostic starts Tuesday."}/>
      </div>

      {/* Action queue + funnel */}
      <Section
        title={lang === "es" ? `Lo que <em style="font-style:italic;color:#2E8169;font-weight:400">requiere mano</em> hoy` : `What needs a <em style="font-style:italic;color:#2E8169;font-weight:400">hand</em> today`}
        meta={lang === "es" ? "4 elementos" : "4 items"}
        margin={lang === "es" ? "Pepe — lo de Bodegas Linares lleva 8 días vencido. Tres recordatorios automáticos. Toca llamar." : "Pepe — Bodegas Linares has been overdue for 8 days. Three auto-reminders sent. Time to call."}
      >
        <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 32 }}>
          {/* Actions */}
          <div>
            {actions.map((a, i) => (
              <a key={i} href={a.href} style={{
                display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 14, alignItems: "center",
                padding: "14px 0", borderBottom: i === actions.length - 1 ? "none" : "1px solid rgba(31,42,38,0.10)",
                textDecoration: "none", color: "inherit",
              }}>
                <span style={{
                  width: 6, height: 6, borderRadius: 999,
                  background: a.kind === "overdue" ? "#cc3c28" : a.kind === "review" ? "#B85F3D" : "#2E8169",
                }}/>
                <div>
                  <div style={{
                    fontFamily: "Newsreader, serif", fontSize: 16, color: "#1F2A26", lineHeight: 1.3,
                  }}>{a.text}</div>
                  <div style={{
                    fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(31,42,38,0.55)",
                    marginTop: 3, letterSpacing: "0.02em",
                  }}>{a.sub}</div>
                </div>
                <Icon name="arrow" size={14}/>
              </a>
            ))}
          </div>

          {/* Funnel */}
          <div>
            <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, letterSpacing: "0.18em",
              textTransform: "uppercase", color: "rgba(31,42,38,0.55)", marginBottom: 12 }}>
              {lang === "es" ? "Embudo · este mes" : "Funnel · this month"}
            </div>
            {stageCounts.map((s, i) => {
              const max = Math.max(...stageCounts.map(x => x.count), 1);
              const pct = (s.count / max) * 100;
              return (
                <div key={s.id} style={{ marginBottom: 10 }}>
                  <div style={{
                    display: "flex", justifyContent: "space-between", alignItems: "baseline",
                    fontFamily: "Inter, sans-serif", fontSize: 12, marginBottom: 4,
                  }}>
                    <span style={{ color: "#3B463F" }}>{s.title[lang]}</span>
                    <span style={{ color: "rgba(31,42,38,0.6)", fontVariantNumeric: "tabular-nums" }}>
                      {s.count}{" · "}{fmtMoney(s.value, lang)}
                    </span>
                  </div>
                  <div style={{ height: 6, background: "rgba(31,42,38,0.06)", borderRadius: 1 }}>
                    <div style={{
                      width: `${pct}%`, height: "100%",
                      background: s.id === "active" ? "#2E8169" : s.id === "lost" ? "rgba(31,42,38,0.2)" : "#1F2A26",
                    }}/>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Section>

      {/* Recent invoices + upcoming */}
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", borderBottom: "1px solid rgba(31,42,38,0.14)" }}>
        <div style={{ borderRight: "1px solid rgba(31,42,38,0.14)" }}>
          <Section title={lang === "es" ? "Facturación reciente" : "Recent invoices"} padded={true}
            right={<a href="#/admin/billing" style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "#2E8169", borderBottom: "1px solid #2E8169" }}>{lang === "es" ? "Ver todas" : "View all"} →</a>}>
            <Table
              columns={[
                { key: "id",      label: "ID",                w: "120px", render: r => <span style={{ fontFamily: "Inter, sans-serif", fontVariantNumeric: "tabular-nums" }}>{r.id}</span>},
                { key: "client",  label: t("common.client"),  w: "1.6fr", render: r => clientOf(r.clientId).name },
                { key: "amount",  label: t("common.value"),   w: "100px", align: "right", render: r => <span style={{ fontVariantNumeric: "tabular-nums" }}>{fmtMoney(r.amount, lang)}</span>},
                { key: "status",  label: "",                  w: "110px", render: r => <StatusPill status={r.status}/>},
              ]}
              rows={recentInvoices}
            />
          </Section>
        </div>
        <Section title={lang === "es" ? "Próximas reuniones" : "Upcoming meetings"} padded={true}
          right={<a href="#/admin/calendar" style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "#2E8169", borderBottom: "1px solid #2E8169" }}>{lang === "es" ? "Calendario" : "Calendar"} →</a>}>
          <div>
            {upcoming.map((ev, i) => {
              const client = clientOf(ev.clientId);
              return (
                <div key={ev.id} style={{
                  padding: "12px 0", borderBottom: i === upcoming.length - 1 ? "none" : "1px solid rgba(31,42,38,0.10)",
                  display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 14, alignItems: "center",
                }}>
                  <div style={{
                    width: 56, fontFamily: "Newsreader, serif", textAlign: "left",
                  }}>
                    <div style={{ fontSize: 14, color: "rgba(31,42,38,0.6)", fontStyle: "italic" }}>
                      {fmtDateShort(ev.date, lang)}
                    </div>
                    <div style={{ fontSize: 18, fontWeight: 400, letterSpacing: "-0.01em", color: "#1F2A26", fontVariantNumeric: "tabular-nums" }}>{ev.time}</div>
                  </div>
                  <div>
                    <div style={{ fontFamily: "Newsreader, serif", fontSize: 15, color: "#1F2A26", lineHeight: 1.3 }}>{ev.title}</div>
                    <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "rgba(31,42,38,0.55)", marginTop: 3 }}>
                      {client ? client.name : (lang === "es" ? "Interno" : "Internal")} · {ev.duration}min
                    </div>
                  </div>
                  <AvatarStack users={ev.attendees.map(userOf)} size={20}/>
                </div>
              );
            })}
          </div>
        </Section>
      </div>
    </>
  );
}

/* ================================================================
   PIPELINE — kanban
   ================================================================ */
function PipelinePage() {
  const t = useT();
  const { lang } = useApp();
  const [view, setView] = useStateInt("kanban"); // kanban | list

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "comercial" : "commercial"}
        title={lang === "es"
          ? `De primera conversación a <em style="font-style:italic;font-weight:300;color:#2E8169">entrada al ecosistema</em>`
          : `From first conversation to <em style="font-style:italic;font-weight:300;color:#2E8169">entering the ecosystem</em>`}
        lede={t("page.pipeline.lede")}
        right={
          <>
            <div style={{ display: "inline-flex", border: "1px solid rgba(31,42,38,0.18)", borderRadius: 3 }}>
              {["kanban", "list"].map(v => (
                <button key={v} type="button" onClick={() => setView(v)} style={{
                  padding: "6px 12px", fontFamily: "Inter, sans-serif", fontSize: 12,
                  background: view === v ? "#1F2A26" : "transparent",
                  color: view === v ? "#F4F1EA" : "#3B463F",
                  border: "none", textTransform: "capitalize", cursor: "pointer",
                }}>{v === "kanban" ? (lang === "es" ? "Kanban" : "Kanban") : (lang === "es" ? "Lista" : "List")}</button>
              ))}
            </div>
            <Btn kind="accent" icon="plus" size="sm">{lang === "es" ? "Nuevo lead" : "New lead"}</Btn>
          </>
        }
      />

      <Toolbar
        right={<>
          <Btn kind="quiet" size="sm" icon="filter">{t("common.filter")}</Btn>
          <Btn kind="quiet" size="sm">{t("common.export")}</Btn>
        </>}
      >
        <FilterChip active>{t("common.all")} <span style={{opacity:.7}}>· {D.clients.filter(c => c.stage !== "lost").length}</span></FilterChip>
        <FilterChip>{lang === "es" ? "Míos" : "Mine"}</FilterChip>
        <FilterChip>{lang === "es" ? "Vencidos > 7d" : "Stale > 7d"}</FilterChip>
        <FilterChip>{lang === "es" ? "Q2 2026" : "Q2 2026"}</FilterChip>
        <span style={{
          fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 13,
          color: "rgba(31,42,38,0.55)", marginLeft: 12,
        }}>
          {lang === "es" ? "Arrastra tarjetas para mover de etapa" : "Drag cards to change stage"}
        </span>
      </Toolbar>

      {view === "kanban" ? <PipelineKanban/> : <PipelineList/>}
    </>
  );
}

function PipelineKanban() {
  const { lang } = useApp();
  const t = useT();
  const stages = D.stages;

  return (
    <div style={{
      display: "grid", gridTemplateColumns: `repeat(${stages.length}, 1fr)`,
      borderTop: "1px solid rgba(31,42,38,0.14)",
      minHeight: "calc(100vh - 280px)",
    }}>
      {stages.map((stage, sIdx) => {
        const cards = D.clients.filter(c => c.stage === stage.id);
        const value = cards.reduce((s, c) => s + (c.mrr || 0) * 12, 0);
        return (
          <div key={stage.id} style={{
            borderRight: sIdx === stages.length - 1 ? "none" : "1px solid rgba(31,42,38,0.10)",
            background: stage.id === "active" ? "rgba(46,129,105,0.04)" : "transparent",
            display: "flex", flexDirection: "column", minHeight: 0,
          }}>
            <div style={{
              padding: "14px 20px 12px",
              borderBottom: "1px solid rgba(31,42,38,0.10)",
              display: "flex", alignItems: "baseline", justifyContent: "space-between",
              background: "rgba(244,241,234,0.6)",
            }}>
              <div>
                <div style={{
                  fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 12,
                  color: "#2E8169", marginBottom: 2,
                }}>— Fase {String(sIdx + 1).padStart(2, "0")}</div>
                <div style={{
                  fontFamily: "Newsreader, serif", fontWeight: 500, fontSize: 16,
                  color: "#1F2A26", letterSpacing: "-0.01em",
                }}>{stage.title[lang]}</div>
              </div>
              <div style={{
                fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)",
                fontVariantNumeric: "tabular-nums", textAlign: "right",
              }}>
                <div>{cards.length}</div>
                {stage.id === "active" && value > 0 && (
                  <div style={{ fontSize: 10, marginTop: 2 }}>{fmtMoney(value, lang)}/y</div>
                )}
              </div>
            </div>

            <div style={{ padding: "10px", flex: 1, display: "flex", flexDirection: "column", gap: 8 }}>
              {cards.map(c => <KanbanCard key={c.id} client={c}/>)}
              {cards.length === 0 && (
                <div style={{
                  border: "1px dashed rgba(31,42,38,0.18)", borderRadius: 3, padding: "20px 12px",
                  textAlign: "center", fontFamily: "Newsreader, serif", fontStyle: "italic",
                  fontSize: 13, color: "rgba(31,42,38,0.4)",
                }}>{lang === "es" ? "vacío" : "empty"}</div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function KanbanCard({ client }) {
  const { lang } = useApp();
  const owner = userOf(client.owner);
  const ageDays = Math.floor((new Date("2026-05-11") - new Date(client.entered)) / 86400000);
  const stale = ageDays > 14 && !["active"].includes(client.stage);
  const est = { lead: 5000, discovery_scheduled: 12000, discovery_done: 22000, proposal_sent: 38000, active: (client.mrr||0)*12 }[client.stage] || 0;

  return (
    <a href={`#/admin/clients/${client.id}`} style={{
      display: "block", padding: "12px 14px",
      background: "#F4F1EA", border: "1px solid rgba(31,42,38,0.10)", borderRadius: 3,
      textDecoration: "none", color: "inherit", cursor: "grab",
      transition: "border-color 150ms, transform 150ms",
    }}
    onMouseEnter={(e) => e.currentTarget.style.borderColor = "rgba(46,129,105,0.4)"}
    onMouseLeave={(e) => e.currentTarget.style.borderColor = "rgba(31,42,38,0.10)"}>
      <div style={{
        fontFamily: "Newsreader, serif", fontSize: 15, fontWeight: 500,
        color: "#1F2A26", lineHeight: 1.2, marginBottom: 4,
      }}>{client.name}</div>
      <div style={{
        fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)",
        marginBottom: 10, letterSpacing: "0.01em",
      }}>{client.sector} · {client.size}</div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Avatar user={owner} size={20}/>
        <div style={{
          fontFamily: "Inter, sans-serif", fontSize: 11.5,
          fontVariantNumeric: "tabular-nums", color: "#1F2A26",
        }}>{est > 0 ? fmtMoney(est, lang) : "—"}</div>
      </div>

      {stale && (
        <div style={{
          marginTop: 8, paddingTop: 8, borderTop: "1px dashed rgba(184,95,61,0.4)",
          fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 11.5,
          color: "#B85F3D",
        }}>{lang === "es" ? `${ageDays} días sin movimiento` : `${ageDays} days idle`}</div>
      )}
    </a>
  );
}

function PipelineList() {
  const { lang } = useApp();
  const t = useT();
  const clients = D.clients.filter(c => c.stage !== "active");

  return (
    <Table
      columns={[
        { key: "name",    label: t("common.client"), w: "1.4fr", render: r => <a href={`#/admin/clients/${r.id}`} style={{color:"#1F2A26", fontWeight:500}}>{r.name}</a>},
        { key: "sector",  label: lang === "es" ? "Sector" : "Sector", w: "1fr", render: r => <span style={{ color: "rgba(31,42,38,0.7)" }}>{r.sector}</span>},
        { key: "stage",   label: t("common.stage"),   w: "180px", render: r => <StatusPill status={r.stage}/>},
        { key: "owner",   label: t("common.owner"),   w: "160px", render: r => <Avatar user={userOf(r.owner)} size={22} label/> },
        { key: "entered", label: lang === "es" ? "Entró" : "Entered", w: "100px", render: r => <span style={{ color: "rgba(31,42,38,0.6)" }}>{fmtDate(r.entered, lang)}</span>},
        { key: "value",   label: t("common.value"),   w: "100px", align: "right", render: r => "—" },
      ]}
      rows={clients}
      onRowClick={(r) => navigate(`/admin/clients/${r.id}`)}
    />
  );
}

/* ================================================================
   CLIENTS LIST
   ================================================================ */
function ClientsPage() {
  const t = useT();
  const { lang } = useApp();
  const [filter, setFilter] = useStateInt("all");

  let rows = D.clients;
  if (filter === "active") rows = rows.filter(c => c.stage === "active");
  else if (filter === "pipeline") rows = rows.filter(c => !["active","lost"].includes(c.stage));
  else if (filter === "lost") rows = rows.filter(c => c.stage === "lost");

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "el ecosistema" : "the ecosystem"}
        title={lang === "es"
          ? `<em style="font-style:italic;font-weight:300;color:#2E8169">Diez</em> empresas, una conversación`
          : `<em style="font-style:italic;font-weight:300;color:#2E8169">Ten</em> companies, one conversation`}
        lede={t("page.clients.lede")}
        right={<Btn kind="accent" icon="plus" size="sm">{lang === "es" ? "Nuevo cliente" : "New client"}</Btn>}
      />
      <Toolbar>
        <FilterChip active={filter==="all"}      onClick={() => setFilter("all")}      count={D.clients.length}>{t("common.all")}</FilterChip>
        <FilterChip active={filter==="active"}   onClick={() => setFilter("active")}   count={D.clients.filter(c => c.stage === "active").length}>{lang === "es" ? "En el ecosistema" : "In ecosystem"}</FilterChip>
        <FilterChip active={filter==="pipeline"} onClick={() => setFilter("pipeline")} count={D.clients.filter(c => !["active","lost"].includes(c.stage)).length}>Pipeline</FilterChip>
        <FilterChip active={filter==="lost"}     onClick={() => setFilter("lost")}     count={D.clients.filter(c => c.stage === "lost").length}>{lang === "es" ? "Perdidos" : "Lost"}</FilterChip>
      </Toolbar>
      <Table
        columns={[
          { key: "name",     label: lang === "es" ? "Empresa" : "Company", w: "1.6fr",
            render: r => (
              <div>
                <div style={{ fontWeight: 500, color: "#1F2A26" }}>{r.name}</div>
                <div style={{ fontSize: 11, color: "rgba(31,42,38,0.55)", marginTop: 2 }}>{r.sector} · {r.region}</div>
              </div>
            )},
          { key: "stage",    label: t("common.stage"),  w: "170px", render: r => <StatusPill status={r.stage}/>},
          { key: "services", label: lang === "es" ? "Servicios" : "Services", w: "1.1fr",
            render: r => {
              const ss = r.services.map(serviceOf).filter(Boolean);
              if (ss.length === 0) return <span style={{ color: "rgba(31,42,38,0.35)", fontStyle: "italic", fontFamily: "Newsreader, serif" }}>—</span>;
              const counts = { assessment: 0, development: 0, formation: 0 };
              ss.forEach(s => counts[s.type]++);
              return (
                <div style={{ display: "flex", gap: 6 }}>
                  {Object.entries(counts).filter(([,n]) => n > 0).map(([type, n]) => (
                    <span key={type} style={{
                      display: "inline-flex", alignItems: "center", gap: 4,
                      fontFamily: "Inter, sans-serif", fontSize: 11,
                      padding: "2px 7px", border: "1px solid rgba(31,42,38,0.14)", borderRadius: 999,
                      color: "#3B463F",
                    }}>
                      <span style={{ width: 5, height: 5, borderRadius: 999,
                        background: type === "assessment" ? "#2E8169" : type === "development" ? "#1F2A26" : "#B85F3D" }}/>
                      {n} {t("svc." + type).toLowerCase()}
                    </span>
                  ))}
                </div>
              );
            }},
          { key: "mrr",      label: t("kpi.mrr"),       w: "120px", align: "right",
            render: r => r.mrr > 0 ? <span style={{ fontVariantNumeric: "tabular-nums" }}>{fmtMoney(r.mrr, lang)}<span style={{ color: "rgba(31,42,38,0.5)", fontSize: 11 }}>{t("common.month")}</span></span> : <span style={{ color: "rgba(31,42,38,0.35)" }}>—</span>},
          { key: "owner",    label: t("common.owner"),  w: "160px", render: r => <Avatar user={userOf(r.owner)} size={22} label/>},
          { key: "entered",  label: lang === "es" ? "Entró" : "Entered", w: "110px", render: r => <span style={{ color: "rgba(31,42,38,0.6)" }}>{fmtDate(r.entered, lang)}</span>},
        ]}
        rows={rows}
        onRowClick={(r) => navigate(`/admin/clients/${r.id}`)}
      />
    </>
  );
}

/* ================================================================
   CLIENT 360
   ================================================================ */
function ClientDetailPage({ id }) {
  const t = useT();
  const { lang } = useApp();
  const c = clientOf(id);
  if (!c) return <div style={{ padding: 40 }}>Not found.</div>;
  const owner = userOf(c.owner);
  const services = c.services.map(serviceOf).filter(Boolean);
  const invoices = D.invoices.filter(i => i.clientId === c.id);
  const events = D.events.filter(e => e.clientId === c.id);
  const docs = D.documents.filter(d => d.clientId === c.id);
  const totalBilled = invoices.filter(i => i.status === "paid").reduce((s, i) => s + i.amount, 0);
  const outstanding = invoices.filter(i => ["pending","overdue"].includes(i.status)).reduce((s, i) => s + i.amount, 0);

  return (
    <>
      {/* Breadcrumb + header */}
      <div style={{
        padding: "20px 40px 12px",
        fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(31,42,38,0.55)",
      }}>
        <a href="#/admin/clients" style={{ color: "rgba(31,42,38,0.55)" }}>{t("nav.clients")}</a>
        <span style={{ margin: "0 8px" }}>/</span>
        <span style={{ color: "#1F2A26" }}>{c.name}</span>
      </div>

      <header style={{
        padding: "0 40px 28px", borderBottom: "1px solid rgba(31,42,38,0.14)",
      }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 32 }}>
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
              <StatusPill status={c.stage}/>
              <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)", letterSpacing: "0.18em", textTransform: "uppercase" }}>
                {lang === "es" ? "En el ecosistema desde" : "In ecosystem since"} {fmtDate(c.entered, lang)}
              </span>
            </div>
            <h1 style={{
              fontFamily: "Newsreader, serif", fontWeight: 400, fontSize: 44,
              letterSpacing: "-0.02em", lineHeight: 1.05, color: "#1F2A26",
              margin: "0 0 8px",
            }}>{c.name}</h1>
            <p style={{
              fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 17,
              color: "rgba(31,42,38,0.6)",
            }}>{c.sector} · {c.size} · {c.region}</p>
          </div>
          <div style={{ display: "flex", gap: 10, flexShrink: 0 }}>
            <Btn kind="ghost" icon="chat" size="sm">{lang === "es" ? "Mensaje" : "Message"}</Btn>
            <Btn kind="ghost" icon="calendar" size="sm">{lang === "es" ? "Agendar" : "Schedule"}</Btn>
            <Btn kind="accent" icon="plus" size="sm">{lang === "es" ? "Nuevo servicio" : "New service"}</Btn>
          </div>
        </div>

        {/* Top stats */}
        <div style={{
          marginTop: 24, display: "grid", gridTemplateColumns: "repeat(4, 1fr)",
          gap: 0, border: "1px solid rgba(31,42,38,0.14)", borderRadius: 3,
        }}>
          <ClientStat label={lang === "es" ? "MRR mantenimiento" : "Maintenance MRR"} value={c.mrr > 0 ? fmtMoney(c.mrr, lang) : "—"} foot={lang === "es" ? "/ mes" : "/ mo"}/>
          <ClientStat label={lang === "es" ? "Facturado total" : "Total billed"} value={fmtMoney(totalBilled, lang)} foot={lang === "es" ? "desde entrada" : "since entry"}/>
          <ClientStat label={lang === "es" ? "Pendiente cobro" : "Outstanding"} value={outstanding > 0 ? fmtMoney(outstanding, lang) : "—"} foot={lang === "es" ? `${invoices.filter(i => ["pending","overdue"].includes(i.status)).length} facturas` : `${invoices.filter(i => ["pending","overdue"].includes(i.status)).length} invoices`}/>
          <ClientStat label={t("common.owner")} value={<Avatar user={owner} size={26} label/>} foot=""/>
        </div>
      </header>

      {/* Two-column: services + sidebar */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 0 }}>
        <div style={{ borderRight: "1px solid rgba(31,42,38,0.14)" }}>
          {/* Services */}
          <Section
            title={lang === "es" ? `Servicios en <em style="font-style:italic;color:#2E8169;font-weight:400">curso</em>` : `Active <em style="font-style:italic;color:#2E8169;font-weight:400">services</em>`}
            meta={`${services.length} ${lang === "es" ? "servicios" : "services"}`}
            right={<Btn kind="quiet" size="sm" icon="plus">{lang === "es" ? "Añadir" : "Add"}</Btn>}
          >
            {services.length === 0 && (
              <div style={{
                padding: "32px 0", textAlign: "center",
                fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 15,
                color: "rgba(31,42,38,0.5)",
              }}>{lang === "es" ? "Aún sin servicios. La conversación está en pipeline." : "No services yet. Conversation is in pipeline."}</div>
            )}
            <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
              {services.map((s, i) => <ServiceRow key={s.id} service={s} client={c}/>)}
            </div>
          </Section>

          {/* Recent invoices */}
          <Section title={lang === "es" ? "Facturación" : "Billing"} meta={`${invoices.length} ${lang === "es" ? "facturas" : "invoices"}`}
            right={<a href="#/admin/billing" style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "#2E8169", borderBottom: "1px solid #2E8169" }}>{lang === "es" ? "Ver todas" : "View all"} →</a>}>
            <Table
              columns={[
                { key: "id", label: "ID", w: "120px", render: r => <span style={{ fontVariantNumeric: "tabular-nums" }}>{r.id}</span>},
                { key: "concept", label: lang === "es" ? "Concepto" : "Concept", w: "1.5fr", render: r => r.concept},
                { key: "issued", label: lang === "es" ? "Emitida" : "Issued", w: "100px", render: r => <span style={{ color: "rgba(31,42,38,0.6)" }}>{fmtDateShort(r.issued, lang)}</span>},
                { key: "amount", label: t("common.value"), w: "100px", align: "right", render: r => <span style={{ fontVariantNumeric: "tabular-nums" }}>{fmtMoney(r.amount, lang)}</span>},
                { key: "status", label: "", w: "100px", render: r => <StatusPill status={r.status}/>},
              ]}
              rows={invoices}
            />
          </Section>

          {/* Activity */}
          <Section title={lang === "es" ? "Actividad" : "Activity"} padded={true}>
            <div style={{ fontFamily: "Newsreader, serif" }}>
              <ActivityItem dot="#2E8169" date="2026-05-09" text={lang === "es" ? "Inés Berrocal aprobó el informe del hito 2." : "Inés Berrocal approved milestone 2 report."}/>
              <ActivityItem dot="#1F2A26" date="2026-05-07" text={lang === "es" ? "Pago recibido vía Stripe · INV-2026-041" : "Payment received via Stripe · INV-2026-041"}/>
              <ActivityItem dot="#B85F3D" date="2026-05-02" text={lang === "es" ? "Diego subió la documentación técnica v0.3." : "Diego uploaded technical doc v0.3."}/>
              <ActivityItem dot="#2E8169" date="2026-04-28" text={lang === "es" ? "Reunión de seguimiento · 60min" : "Follow-up meeting · 60min"}/>
              <ActivityItem dot="#1F2A26" date="2026-04-15" text={lang === "es" ? "Comenzó hito 2: integración API ERP." : "Started milestone 2: ERP API integration."}/>
            </div>
          </Section>
        </div>

        {/* Sidebar */}
        <aside style={{ padding: "24px 28px" }}>
          <SidePanel title={lang === "es" ? "Contactos" : "Contacts"}>
            {c.contacts.map((p, i) => (
              <div key={i} style={{ padding: "10px 0", borderBottom: i === c.contacts.length - 1 ? "none" : "1px solid rgba(31,42,38,0.10)" }}>
                <div style={{ fontFamily: "Newsreader, serif", fontSize: 15, color: "#1F2A26" }}>{p.name}</div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "rgba(31,42,38,0.6)" }}>{p.role}</div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "#2E8169", marginTop: 2 }}>{p.email}</div>
              </div>
            ))}
          </SidePanel>

          <SidePanel title={lang === "es" ? "Próxima reunión" : "Next meeting"}>
            {events.length > 0 ? (
              <div>
                <div style={{ fontFamily: "Newsreader, serif", fontSize: 15, color: "#1F2A26" }}>{events[0].title}</div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(31,42,38,0.6)", marginTop: 4 }}>
                  {fmtDate(events[0].date, lang)} · {events[0].time}
                </div>
                <div style={{ marginTop: 10, display: "flex", alignItems: "center", gap: 8 }}>
                  <Icon name="google" size={14}/>
                  <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)" }}>
                    {lang === "es" ? "Sincronizado con Google Calendar" : "Synced with Google Calendar"}
                  </span>
                </div>
              </div>
            ) : (
              <span style={{ fontFamily: "Newsreader, serif", fontStyle: "italic", color: "rgba(31,42,38,0.45)" }}>{lang === "es" ? "Nada agendado." : "Nothing scheduled."}</span>
            )}
          </SidePanel>

          <SidePanel title={lang === "es" ? "Documentos" : "Documents"}>
            {docs.length === 0 && <span style={{ fontFamily: "Newsreader, serif", fontStyle: "italic", color: "rgba(31,42,38,0.45)" }}>—</span>}
            {docs.map(d => (
              <a key={d.id} href="#" style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                padding: "8px 0", borderBottom: "1px solid rgba(31,42,38,0.08)",
                textDecoration: "none",
              }}>
                <div>
                  <div style={{ fontFamily: "Inter, sans-serif", fontSize: 12.5, color: "#1F2A26" }}>{d.name}</div>
                  <div style={{ fontFamily: "Inter, sans-serif", fontSize: 10.5, color: "rgba(31,42,38,0.55)", marginTop: 2 }}>{d.kind} · {d.size}</div>
                </div>
                <Icon name="ext" size={13}/>
              </a>
            ))}
          </SidePanel>

          <div style={{
            marginTop: 24, padding: "14px 16px",
            background: "rgba(184,95,61,0.06)", borderLeft: "1px solid #B85F3D",
            fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 13,
            color: "#B85F3D", lineHeight: 1.45,
          }}>
            {lang === "es"
              ? <>Nota de Marta: <i>Pablo prefiere las llamadas los miércoles a primera hora. No le gustan los emails largos.</i></>
              : <>Note from Marta: <i>Pablo prefers Wednesday morning calls. Doesn't like long emails.</i></>}
          </div>
        </aside>
      </div>
    </>
  );
}

function ClientStat({ label, value, foot }) {
  return (
    <div style={{ padding: "16px 22px", borderRight: "1px solid rgba(31,42,38,0.10)" }}>
      <div style={{
        fontFamily: "Inter, sans-serif", fontSize: 10.5, letterSpacing: "0.18em",
        textTransform: "uppercase", color: "rgba(31,42,38,0.55)", marginBottom: 8,
      }}>{label}</div>
      <div style={{
        display: "flex", alignItems: "baseline", gap: 8,
        fontFamily: "Newsreader, serif", fontWeight: 400, fontSize: 24,
        color: "#1F2A26", letterSpacing: "-0.015em",
      }}>{value} {foot && <span style={{ fontSize: 12, color: "rgba(31,42,38,0.5)", fontStyle: "italic" }}>{foot}</span>}</div>
    </div>
  );
}

function ServiceRow({ service, client }) {
  const { lang } = useApp();
  const t = useT();
  const owner = userOf(service.owner);
  return (
    <a href={`#/admin/services/${service.id}`} style={{
      display: "grid", gridTemplateColumns: "180px 1fr 130px 100px 90px",
      gap: 18, alignItems: "center", padding: "16px 0",
      borderBottom: "1px solid rgba(31,42,38,0.08)",
      textDecoration: "none", color: "inherit",
    }}>
      <ServiceTypeBadge type={service.type}/>
      <div>
        <div style={{ fontFamily: "Newsreader, serif", fontSize: 15, color: "#1F2A26", lineHeight: 1.3 }}>{service.title}</div>
        <div style={{ marginTop: 6, display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ flex: 1, maxWidth: 240 }}>
            <Progress value={service.progress} color={service.type === "assessment" ? "#2E8169" : service.type === "formation" ? "#B85F3D" : "#1F2A26"}/>
          </div>
          <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)", fontVariantNumeric: "tabular-nums" }}>{service.progress}%</span>
        </div>
      </div>
      <StatusPill status={service.state}/>
      <div style={{ textAlign: "right" }}>
        {service.type === "development" ? (
          <>
            <div style={{ fontFamily: "Inter, sans-serif", fontSize: 13, color: "#1F2A26", fontVariantNumeric: "tabular-nums" }}>{fmtMoney(service.setupPrice, lang)}</div>
            <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)", fontVariantNumeric: "tabular-nums" }}>+ {fmtMoney(service.monthly, lang)}/m</div>
          </>
        ) : (
          <div style={{ fontFamily: "Inter, sans-serif", fontSize: 13, color: "#1F2A26", fontVariantNumeric: "tabular-nums" }}>{fmtMoney(service.setupPrice, lang)}</div>
        )}
      </div>
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <Avatar user={owner} size={22}/>
      </div>
    </a>
  );
}

function ActivityItem({ dot, date, text }) {
  const { lang } = useApp();
  return (
    <div style={{
      display: "grid", gridTemplateColumns: "12px 1fr 80px",
      gap: 16, padding: "10px 0", alignItems: "center",
      borderBottom: "1px solid rgba(31,42,38,0.08)",
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 999, background: dot, marginLeft: 3 }}/>
      <span style={{ fontFamily: "Newsreader, serif", fontSize: 14.5, color: "#3B463F" }}>{text}</span>
      <span style={{
        fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.5)",
        letterSpacing: "0.02em", textAlign: "right",
      }}>{fmtDateShort(date, lang)}</span>
    </div>
  );
}

function SidePanel({ title, children }) {
  return (
    <div style={{ marginBottom: 28 }}>
      <h3 style={{
        fontFamily: "Inter, sans-serif", fontSize: 11, letterSpacing: "0.18em",
        textTransform: "uppercase", color: "rgba(31,42,38,0.55)", margin: "0 0 12px",
      }}>{title}</h3>
      <div>{children}</div>
    </div>
  );
}

Object.assign(window, {
  DashboardPage, PipelinePage, ClientsPage, ClientDetailPage,
  ServiceRow, ClientStat, ActivityItem, SidePanel,
});
