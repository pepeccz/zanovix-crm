// Internal-side pages part 2: Service detail, Billing, Calendar, Team.

const { useState: useStateIp2, useMemo: useMemoIp2 } = React;
const D2 = window.DATA;
const { fmtMoney: fmtMoney2, fmtDate: fmtDate2, fmtDateShort: fmtDateShort2, userOf: userOf2, clientOf: clientOf2, serviceOf: serviceOf2 } = window.helpers;

/* ================================================================
   SERVICE DETAIL
   ================================================================ */
function ServiceDetailPage({ id }) {
  const t = useT();
  const { lang } = useApp();
  const s = serviceOf2(id);
  if (!s) return <div style={{ padding: 40 }}>Not found.</div>;
  const client = clientOf2(s.clientId);
  const owner = userOf2(s.owner);

  // mock milestones per service
  const milestones = s.type === "assessment"
    ? [
        { n: 1, title: lang === "es" ? "Mapa de procesos" : "Process map", done: true, due: "2026-02-09" },
        { n: 2, title: lang === "es" ? "Auditoría de datos" : "Data audit", done: true, due: "2026-02-16" },
        { n: 3, title: lang === "es" ? "Cumplimiento (AI Act, GDPR)" : "Compliance (AI Act, GDPR)", done: s.state === "completed", due: "2026-02-20" },
        { n: 4, title: lang === "es" ? "Plan priorizado + scoring" : "Prioritised plan + scoring", done: s.state === "completed", due: "2026-02-23" },
      ]
    : s.type === "development"
    ? [
        { n: 1, title: lang === "es" ? "Arquitectura validada" : "Architecture signed-off", done: s.progress >= 25, due: "2026-03-22" },
        { n: 2, title: lang === "es" ? "MVP funcional + integraciones" : "Working MVP + integrations", done: s.progress >= 50, due: "2026-04-19" },
        { n: 3, title: lang === "es" ? "Pruebas con casos reales" : "Real-case validation", done: s.progress >= 75, due: "2026-05-17" },
        { n: 4, title: lang === "es" ? "Formación + documentación + entrega" : "Training + documentation + handover", done: s.progress >= 100, due: "2026-06-21" },
      ]
    : [
        { n: 1, title: lang === "es" ? "Sesión 1 · Marco general" : "Session 1 · Framework", done: true, due: "2026-05-21" },
        { n: 2, title: lang === "es" ? "Sesión 2 · Gobierno y compliance" : "Session 2 · Governance & compliance", done: false, due: "2026-05-28" },
        { n: 3, title: lang === "es" ? "Sesión 3 · Casos prácticos" : "Session 3 · Case workshops", done: false, due: "2026-06-04" },
        { n: 4, title: lang === "es" ? "Sesión 4 · Plan de adopción" : "Session 4 · Adoption plan", done: false, due: "2026-06-11" },
      ];

  const invoices = D2.invoices.filter(i => i.serviceId === s.id);

  return (
    <>
      {/* Breadcrumb */}
      <div style={{ padding: "20px 40px 12px", fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(31,42,38,0.55)" }}>
        <a href="#/admin/clients" style={{ color: "rgba(31,42,38,0.55)" }}>{t("nav.clients")}</a>
        <span style={{ margin: "0 8px" }}>/</span>
        <a href={`#/admin/clients/${client.id}`} style={{ color: "rgba(31,42,38,0.55)" }}>{client.name}</a>
        <span style={{ margin: "0 8px" }}>/</span>
        <span style={{ color: "#1F2A26" }}>{s.title}</span>
      </div>

      <header style={{ padding: "0 40px 28px", borderBottom: "1px solid rgba(31,42,38,0.14)" }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 32 }}>
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
              <ServiceTypeBadge type={s.type}/>
              <StatusPill status={s.state}/>
            </div>
            <h1 style={{
              fontFamily: "Newsreader, serif", fontWeight: 400, fontSize: 38,
              letterSpacing: "-0.02em", lineHeight: 1.1, color: "#1F2A26",
              margin: "0 0 8px", textWrap: "balance", maxWidth: 800,
            }}>{s.title}</h1>
            <p style={{ fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 16, color: "rgba(31,42,38,0.6)" }}>
              {lang === "es" ? `Para ${client.name} · responsable ` : `For ${client.name} · led by `}
              {owner.name}
            </p>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <Btn kind="ghost" size="sm" icon="doc">{lang === "es" ? "Documentos" : "Documents"}</Btn>
            <Btn kind="ghost" size="sm" icon="calendar">{lang === "es" ? "Programar sesión" : "Schedule session"}</Btn>
            <Btn kind="accent" size="sm">{lang === "es" ? "Marcar hito" : "Mark milestone"}</Btn>
          </div>
        </div>

        {/* Stats */}
        <div style={{ marginTop: 24, display: "grid", gridTemplateColumns: "repeat(4, 1fr)",
          border: "1px solid rgba(31,42,38,0.14)", borderRadius: 3 }}>
          <ClientStat label={lang === "es" ? "Progreso" : "Progress"} value={`${s.progress}%`} foot=""/>
          <ClientStat label={s.type === "development" ? (lang === "es" ? "Pago de desarrollo" : "Development fee") : (lang === "es" ? "Pago único" : "One-time")} value={fmtMoney2(s.setupPrice, lang)} foot=""/>
          {s.type === "development" ? (
            <ClientStat label={lang === "es" ? "Mantenimiento" : "Maintenance"} value={fmtMoney2(s.monthly, lang)} foot={lang === "es" ? "/ mes" : "/ mo"}/>
          ) : (
            <ClientStat label={lang === "es" ? "Sesiones / hitos" : "Sessions / milestones"} value={milestones.length} foot=""/>
          )}
          <ClientStat label={lang === "es" ? "Inicio" : "Started"} value={s.started ? fmtDate2(s.started, lang) : (lang === "es" ? "Sin iniciar" : "Not started")} foot=""/>
        </div>
      </header>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px" }}>
        <div style={{ borderRight: "1px solid rgba(31,42,38,0.14)" }}>
          {/* Milestones */}
          <Section title={lang === "es" ? `<em style="font-style:italic;color:#2E8169;font-weight:400">Hitos</em> del servicio` : `Service <em style="font-style:italic;color:#2E8169;font-weight:400">milestones</em>`}
            margin={s.type === "assessment"
              ? (lang === "es" ? "El diagnóstico no es un entregable, es una conversación de tres semanas." : "The diagnostic isn't a deliverable, it's a three-week conversation.")
              : s.type === "development"
              ? (lang === "es" ? "Cuatro hitos cerrados. Si uno se retrasa, vuelve al taller." : "Four sealed milestones. If one slips, back to the workshop.")
              : (lang === "es" ? "Cada sesión incluye material previo y trabajo posterior." : "Each session includes pre-reading and follow-up work.")
            }
          >
            <ol style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {milestones.map((m, i) => (
                <li key={m.n} style={{
                  display: "grid", gridTemplateColumns: "80px 28px 1fr 120px",
                  gap: 16, alignItems: "center", padding: "18px 0",
                  borderTop: i === 0 ? "1px solid rgba(31,42,38,0.14)" : "none",
                  borderBottom: "1px solid rgba(31,42,38,0.10)",
                }}>
                  <span style={{
                    fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 28,
                    color: m.done ? "#2E8169" : "rgba(31,42,38,0.25)", fontWeight: 300, lineHeight: 1,
                  }}>{String(m.n).padStart(2, "0")}</span>
                  <span style={{
                    width: 20, height: 20, borderRadius: 999,
                    border: `1.5px solid ${m.done ? "#2E8169" : "rgba(31,42,38,0.25)"}`,
                    background: m.done ? "#2E8169" : "transparent",
                    display: "inline-flex", alignItems: "center", justifyContent: "center",
                    color: "#F4F1EA",
                  }}>{m.done && <Icon name="check" size={12}/>}</span>
                  <span style={{
                    fontFamily: "Newsreader, serif", fontSize: 17,
                    color: m.done ? "#1F2A26" : "rgba(31,42,38,0.7)",
                    textDecoration: m.done ? "none" : "none",
                  }}>{m.title}</span>
                  <span style={{
                    fontFamily: "Inter, sans-serif", fontSize: 12,
                    color: "rgba(31,42,38,0.55)", textAlign: "right",
                  }}>{fmtDate2(m.due, lang)}</span>
                </li>
              ))}
            </ol>
          </Section>

          {/* Score for assessment */}
          {s.type === "assessment" && s.state === "completed" && (
            <Section title={lang === "es" ? `AI Readiness <em style="font-style:italic;color:#2E8169;font-weight:400">Score</em>` : `AI Readiness <em style="font-style:italic;color:#2E8169;font-weight:400">Score</em>`}>
              <ScoreBlock score={s.score}/>
            </Section>
          )}

          {/* Billing for this service */}
          {invoices.length > 0 && (
            <Section title={lang === "es" ? "Facturación asociada" : "Linked billing"}>
              <Table
                columns={[
                  { key: "id", label: "ID", w: "120px", render: r => <span style={{ fontVariantNumeric: "tabular-nums" }}>{r.id}</span>},
                  { key: "concept", label: lang === "es" ? "Concepto" : "Concept", w: "1.5fr"},
                  { key: "issued", label: lang === "es" ? "Emitida" : "Issued", w: "100px", render: r => <span style={{ color: "rgba(31,42,38,0.6)" }}>{fmtDateShort2(r.issued, lang)}</span>},
                  { key: "amount", label: t("common.value"), w: "100px", align: "right", render: r => <span style={{ fontVariantNumeric: "tabular-nums" }}>{fmtMoney2(r.amount, lang)}</span>},
                  { key: "status", label: "", w: "100px", render: r => <StatusPill status={r.status}/>},
                ]}
                rows={invoices}
              />
            </Section>
          )}
        </div>

        <aside style={{ padding: "24px 28px" }}>
          <SidePanel title={lang === "es" ? "Equipo asignado" : "Assigned team"}>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <Avatar user={owner} size={26} label/>
              {s.type === "development" && <Avatar user={userOf2("u-diego")} size={26} label/>}
              {s.type === "formation" && <Avatar user={userOf2("u-pepe")} size={26} label/>}
            </div>
          </SidePanel>
          <SidePanel title={lang === "es" ? "Stack / integraciones" : "Stack / integrations"}>
            <div style={{ fontFamily: "Inter, sans-serif", fontSize: 12.5, color: "#3B463F", lineHeight: 1.7 }}>
              {s.type === "development" && (
                <>
                  · Python · LangGraph<br/>
                  · Pinecone (RAG)<br/>
                  · GPT-4o + Claude<br/>
                  · {client.name === "Naviera Mediterránea" ? "SAP S/4HANA" : client.name === "Cárnicas Del Sur" ? "Sage X3" : "API REST cliente"}<br/>
                </>
              )}
              {s.type === "assessment" && (
                <>
                  · Mapa de procesos<br/>
                  · Inventario sistemas<br/>
                  · AI Act assessment<br/>
                  · GDPR DPIA<br/>
                </>
              )}
              {s.type === "formation" && (
                <>
                  · 4 sesiones presenciales<br/>
                  · Material exclusivo<br/>
                  · Caso práctico {client.sector}<br/>
                  · Acompañamiento post<br/>
                </>
              )}
            </div>
          </SidePanel>
          <SidePanel title={lang === "es" ? "Visible para el cliente" : "Visible to client"}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <span style={{ width: 32, height: 18, borderRadius: 999, background: "#2E8169", position: "relative" }}>
                <span style={{ position: "absolute", right: 2, top: 2, width: 14, height: 14, borderRadius: 999, background: "#F4F1EA" }}/>
              </span>
              <span style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "#1F2A26" }}>
                {lang === "es" ? "El cliente ve este servicio" : "Client can see this service"}
              </span>
            </div>
            <p style={{ fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 12.5, color: "rgba(31,42,38,0.6)", lineHeight: 1.4 }}>
              {lang === "es"
                ? "Progreso, hitos y documentos compartidos aparecen en su portal."
                : "Progress, milestones and shared documents show in their portal."}
            </p>
          </SidePanel>
        </aside>
      </div>
    </>
  );
}

function ScoreBlock({ score }) {
  const { lang } = useApp();
  const dimensions = [
    { name: lang === "es" ? "Datos" : "Data",                      v: 58 },
    { name: lang === "es" ? "Procesos" : "Process",                v: 64 },
    { name: lang === "es" ? "Equipo & cultura" : "Team & culture", v: 71 },
    { name: lang === "es" ? "Infraestructura" : "Infrastructure",  v: 52 },
    { name: lang === "es" ? "Cumplimiento" : "Compliance",         v: 76 },
    { name: lang === "es" ? "Liderazgo IA" : "AI leadership",      v: 49 },
  ];
  return (
    <div style={{ display: "grid", gridTemplateColumns: "240px 1fr", gap: 40, alignItems: "center", padding: "12px 0" }}>
      {/* big score */}
      <div style={{ textAlign: "center" }}>
        <div style={{
          fontFamily: "Newsreader, serif", fontWeight: 300, fontSize: 96,
          letterSpacing: "-0.04em", color: "#2E8169", lineHeight: 1,
        }}>{score}</div>
        <div style={{
          fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 14,
          color: "rgba(31,42,38,0.55)", marginTop: 8,
        }}>{lang === "es" ? "de 100 · escala Zanovix" : "of 100 · Zanovix scale"}</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {dimensions.map(d => (
          <div key={d.name}>
            <div style={{
              display: "flex", justifyContent: "space-between",
              fontFamily: "Inter, sans-serif", fontSize: 12, color: "#3B463F", marginBottom: 4,
            }}>
              <span>{d.name}</span>
              <span style={{ fontVariantNumeric: "tabular-nums", color: "rgba(31,42,38,0.55)" }}>{d.v}/100</span>
            </div>
            <div style={{ height: 5, background: "rgba(31,42,38,0.08)" }}>
              <div style={{ width: `${d.v}%`, height: "100%", background: d.v >= 70 ? "#2E8169" : d.v >= 50 ? "#1F2A26" : "#B85F3D" }}/>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================================================================
   BILLING
   ================================================================ */
function BillingPage() {
  const t = useT();
  const { lang } = useApp();
  const [filter, setFilter] = useStateIp2("all");
  let rows = D2.invoices.filter(i => i.issued); // skip drafts in default
  if (filter === "paid")    rows = rows.filter(r => r.status === "paid");
  if (filter === "pending") rows = rows.filter(r => r.status === "pending");
  if (filter === "overdue") rows = rows.filter(r => r.status === "overdue");
  if (filter === "draft")   rows = D2.invoices.filter(r => r.status === "draft");

  rows = [...rows].sort((a,b) => (b.issued || "").localeCompare(a.issued || ""));

  const totalPaid = D2.invoices.filter(i => i.status === "paid").reduce((s,i) => s + i.amount, 0);
  const outstanding = D2.invoices.filter(i => ["pending","overdue"].includes(i.status)).reduce((s,i) => s + i.amount, 0);
  const recurring = D2.clients.reduce((s,c) => s + (c.mrr || 0), 0);

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "ingresos" : "revenue"}
        title={lang === "es"
          ? `Pagos únicos y <em style="font-style:italic;font-weight:300;color:#2E8169">recurrentes</em>`
          : `One-time and <em style="font-style:italic;font-weight:300;color:#2E8169">recurring</em> payments`}
        lede={t("page.billing.lede")}
        right={
          <>
            <Btn kind="ghost" size="sm" icon="ext">{lang === "es" ? "Exportar XLSX" : "Export XLSX"}</Btn>
            <Btn kind="accent" size="sm" icon="plus">{lang === "es" ? "Nueva factura" : "New invoice"}</Btn>
          </>
        }
      />

      {/* KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)",
        borderBottom: "1px solid rgba(31,42,38,0.14)", padding: "0 16px" }}>
        <KPI label={lang === "es" ? "Recurrente mensual" : "Monthly recurring"} value={fmtMoney2(recurring, lang)} delta="+580 €"
          footnote={lang === "es" ? "Nueve servicios en mantenimiento." : "Nine services on maintenance."}/>
        <KPI label={lang === "es" ? "Cobrado YTD" : "Billed YTD"} value={fmtMoney2(totalPaid, lang)} delta="+18%"
          footnote={lang === "es" ? "Sobre 2025: subida sostenida." : "Vs 2025: steady increase."}/>
        <KPI label={lang === "es" ? "Pendiente cobro" : "Outstanding"} value={fmtMoney2(outstanding, lang)} delta="−2"
          footnote={lang === "es" ? "Una factura vencida — Bodegas Linares." : "One overdue — Bodegas Linares."}/>
        <KPI label={lang === "es" ? "Próximas recurrentes" : "Upcoming recurring"} value={"4"} delta=""
          footnote={lang === "es" ? "Se emiten el 1 de junio." : "Issue on June 1."}/>
      </div>

      <Toolbar
        right={
          <>
            <Btn kind="quiet" size="sm" icon="filter">{lang === "es" ? "Cliente" : "Client"}</Btn>
            <Btn kind="quiet" size="sm">{t("common.this_month")}</Btn>
          </>
        }
      >
        <FilterChip active={filter==="all"}     onClick={() => setFilter("all")}     count={D2.invoices.filter(i => i.issued).length}>{t("common.all")}</FilterChip>
        <FilterChip active={filter==="paid"}    onClick={() => setFilter("paid")}    count={D2.invoices.filter(i => i.status === "paid").length}>{t("status.paid")}</FilterChip>
        <FilterChip active={filter==="pending"} onClick={() => setFilter("pending")} count={D2.invoices.filter(i => i.status === "pending").length}>{t("status.pending")}</FilterChip>
        <FilterChip active={filter==="overdue"} onClick={() => setFilter("overdue")} count={D2.invoices.filter(i => i.status === "overdue").length}>{t("status.overdue")}</FilterChip>
        <FilterChip active={filter==="draft"}   onClick={() => setFilter("draft")}   count={D2.invoices.filter(i => i.status === "draft").length}>{t("status.draft")}</FilterChip>
      </Toolbar>

      <Table
        columns={[
          { key: "id",     label: "ID",                                w: "130px", render: r => <span style={{ fontFamily: "Inter, sans-serif", fontVariantNumeric: "tabular-nums" }}>{r.id}</span>},
          { key: "client", label: t("common.client"),                  w: "1fr",   render: r => (
            <a href={`#/admin/clients/${r.clientId}`} style={{ color: "#1F2A26", textDecoration: "none" }}>{clientOf2(r.clientId).name}</a>
          )},
          { key: "concept", label: lang === "es" ? "Concepto" : "Concept", w: "1.4fr",
            render: r => (
              <div>
                <div>{r.concept}</div>
                {r.recurring && <div style={{ fontSize: 11, color: "#2E8169", fontStyle: "italic", fontFamily: "Newsreader, serif", marginTop: 2 }}>{lang === "es" ? "recurrente mensual" : "monthly recurring"}</div>}
              </div>
            )},
          { key: "method", label: lang === "es" ? "Método" : "Method", w: "110px", render: r => r.method ? (
            <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "rgba(31,42,38,0.7)" }}>
              <Icon name={r.method === "stripe" ? "stripe" : "billing"} size={14}/>
              {r.method === "stripe" ? "Stripe" : (lang === "es" ? "Transferencia" : "Transfer")}
            </span>
          ) : "—"},
          { key: "issued", label: lang === "es" ? "Emitida" : "Issued", w: "100px", render: r => <span style={{ color: "rgba(31,42,38,0.6)" }}>{fmtDateShort2(r.issued, lang)}</span>},
          { key: "due",    label: lang === "es" ? "Vencimiento" : "Due", w: "100px", render: r => <span style={{ color: r.status === "overdue" ? "#cc3c28" : "rgba(31,42,38,0.6)" }}>{fmtDateShort2(r.due, lang)}</span>},
          { key: "amount", label: t("common.value"),                   w: "100px", align: "right", render: r => <span style={{ fontVariantNumeric: "tabular-nums", fontWeight: 500 }}>{fmtMoney2(r.amount, lang)}</span>},
          { key: "status", label: "",                                  w: "100px", render: r => <StatusPill status={r.status}/>},
        ]}
        rows={rows}
      />
    </>
  );
}

/* ================================================================
   CALENDAR
   ================================================================ */
function CalendarPage() {
  const t = useT();
  const { lang } = useApp();

  // Build the week May 11–17, 2026 (Mon–Sun)
  const weekStart = new Date("2026-05-11T00:00:00");
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStart);
    d.setDate(weekStart.getDate() + i);
    return d;
  });
  const dayNames = lang === "es"
    ? ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]
    : ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  const eventsByDay = days.map(d => {
    const iso = d.toISOString().slice(0, 10);
    return D2.events.filter(e => e.date === iso).sort((a,b) => a.time.localeCompare(b.time));
  });

  const kindColor = {
    discovery: "#B85F3D",
    assessment: "#2E8169",
    review: "#1F2A26",
    formation: "#B85F3D",
    proposal: "#2E8169",
    demo: "#1F2A26",
    internal: "rgba(31,42,38,0.45)",
  };

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "agenda" : "agenda"}
        title={lang === "es"
          ? `<em style="font-style:italic;font-weight:300;color:#2E8169">Esta semana</em> en el ecosistema`
          : `<em style="font-style:italic;font-weight:300;color:#2E8169">This week</em> in the ecosystem`}
        lede={t("page.calendar.lede")}
        right={
          <>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Icon name="google" size={16}/>
              <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "rgba(31,42,38,0.6)" }}>
                {lang === "es" ? "Sincronizado hace 2 minutos" : "Synced 2 minutes ago"}
              </span>
            </div>
            <Btn kind="accent" size="sm" icon="plus">{lang === "es" ? "Nuevo evento" : "New event"}</Btn>
          </>
        }
      />

      <Toolbar right={
        <div style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
          <Btn kind="ghost" size="sm">‹</Btn>
          <span style={{ fontFamily: "Newsreader, serif", fontSize: 15, color: "#1F2A26", fontStyle: "italic" }}>
            {lang === "es" ? "11 – 17 mayo · 2026" : "11 – 17 May · 2026"}
          </span>
          <Btn kind="ghost" size="sm">›</Btn>
        </div>
      }>
        <FilterChip active>{lang === "es" ? "Semana" : "Week"}</FilterChip>
        <FilterChip>{lang === "es" ? "Mes" : "Month"}</FilterChip>
        <FilterChip>{lang === "es" ? "Lista" : "List"}</FilterChip>
        <span style={{ marginLeft: 16, display: "inline-flex", gap: 12, alignItems: "center", fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)" }}>
          {[
            ["discovery", lang === "es" ? "Discovery" : "Discovery"],
            ["assessment", lang === "es" ? "Diagnóstico" : "Diagnostic"],
            ["review", lang === "es" ? "Revisión" : "Review"],
            ["formation", lang === "es" ? "Formación" : "Training"],
          ].map(([k, l]) => (
            <span key={k} style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
              <span style={{ width: 8, height: 8, borderRadius: 1, background: kindColor[k] }}/>{l}
            </span>
          ))}
        </span>
      </Toolbar>

      {/* Week grid */}
      <div style={{ display: "grid", gridTemplateColumns: "60px repeat(7, 1fr)",
        borderBottom: "1px solid rgba(31,42,38,0.14)" }}>
        <div/>
        {days.map((d, i) => (
          <div key={i} style={{
            padding: "14px 16px", borderLeft: "1px solid rgba(31,42,38,0.10)",
            background: d.toDateString() === new Date("2026-05-11").toDateString() ? "rgba(46,129,105,0.06)" : "transparent",
          }}>
            <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, letterSpacing: "0.18em", textTransform: "uppercase", color: "rgba(31,42,38,0.55)" }}>{dayNames[i]}</div>
            <div style={{ fontFamily: "Newsreader, serif", fontSize: 24, fontWeight: 400, color: "#1F2A26", marginTop: 4, letterSpacing: "-0.01em" }}>{d.getDate()}</div>
          </div>
        ))}
      </div>

      <div style={{ position: "relative", display: "grid", gridTemplateColumns: "60px repeat(7, 1fr)",
        minHeight: 720, paddingBottom: 40 }}>
        {/* time labels */}
        <div style={{ borderRight: "1px solid rgba(31,42,38,0.10)" }}>
          {Array.from({ length: 10 }, (_, i) => i + 8).map(h => (
            <div key={h} style={{
              height: 60, paddingRight: 8, textAlign: "right", paddingTop: 4,
              fontFamily: "Inter, sans-serif", fontSize: 10.5,
              color: "rgba(31,42,38,0.45)", borderBottom: "1px dashed rgba(31,42,38,0.06)",
            }}>{String(h).padStart(2, "0")}:00</div>
          ))}
        </div>
        {/* day columns */}
        {days.map((d, dIdx) => (
          <div key={dIdx} style={{
            position: "relative", borderRight: dIdx === 6 ? "none" : "1px solid rgba(31,42,38,0.10)",
            background: d.toDateString() === new Date("2026-05-11").toDateString() ? "rgba(46,129,105,0.025)" : "transparent",
          }}>
            {Array.from({ length: 10 }, (_, i) => (
              <div key={i} style={{ height: 60, borderBottom: "1px dashed rgba(31,42,38,0.06)" }}/>
            ))}
            {eventsByDay[dIdx].map(ev => {
              const [hh, mm] = ev.time.split(":").map(Number);
              const top = (hh - 8) * 60 + mm;
              const height = ev.duration;
              return (
                <div key={ev.id} style={{
                  position: "absolute", left: 6, right: 6, top: top, height: height - 2,
                  background: "#F4F1EA",
                  border: `1px solid ${kindColor[ev.kind] || "#1F2A26"}`,
                  borderLeft: `3px solid ${kindColor[ev.kind] || "#1F2A26"}`,
                  borderRadius: 2, padding: "5px 8px", overflow: "hidden",
                  cursor: "pointer",
                }}>
                  <div style={{ fontFamily: "Inter, sans-serif", fontSize: 10.5,
                    color: kindColor[ev.kind], fontVariantNumeric: "tabular-nums", letterSpacing: "0.02em" }}>{ev.time}</div>
                  <div style={{ fontFamily: "Newsreader, serif", fontSize: 12, fontWeight: 500, color: "#1F2A26", lineHeight: 1.25, marginTop: 1 }}>{ev.title}</div>
                  {ev.attendees && ev.duration >= 60 && (
                    <div style={{ marginTop: 4, display: "flex", gap: -4 }}>
                      <AvatarStack users={ev.attendees.map(userOf2).slice(0, 3)} size={16}/>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </>
  );
}

/* ================================================================
   TEAM
   ================================================================ */
function TeamPage() {
  const t = useT();
  const { lang } = useApp();

  const roleLabel = (r) => {
    if (lang === "es") return { founder: "Fundador · admin", consultant: "Consultor", developer: "Desarrollador", pm: "Project Manager" }[r] || r;
    return { founder: "Founder · admin", consultant: "Consultant", developer: "Developer", pm: "Project Manager" }[r] || r;
  };
  const capacity = { founder: 70, consultant: 85, developer: 92, pm: 50 };

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "quiénes formamos parte" : "who's part of it"}
        title={lang === "es"
          ? `El <em style="font-style:italic;font-weight:300;color:#2E8169">equipo</em> tiene cara`
          : `The <em style="font-style:italic;font-weight:300;color:#2E8169">team</em> has a face`}
        lede={t("page.team.lede")}
        right={<Btn kind="accent" size="sm" icon="plus">{lang === "es" ? "Invitar" : "Invite"}</Btn>}
      />
      <Toolbar
        right={<Btn kind="quiet" size="sm">{lang === "es" ? "Roles y permisos" : "Roles & permissions"} →</Btn>}>
        <FilterChip active>{t("common.all")} <span style={{opacity:.7}}>· {D2.team.length}</span></FilterChip>
        <FilterChip>{lang === "es" ? "Consultores" : "Consultants"}</FilterChip>
        <FilterChip>{lang === "es" ? "Desarrolladores" : "Developers"}</FilterChip>
      </Toolbar>

      <div>
        {D2.team.map((u, i) => {
          const assigned = D2.services.filter(s => s.owner === u.id);
          const clients = D2.clients.filter(c => c.owner === u.id);
          const cap = capacity[u.role] || 60;
          return (
            <div key={u.id} style={{
              display: "grid", gridTemplateColumns: "260px 1fr 1fr 1fr 120px",
              gap: 24, padding: "20px 40px",
              borderBottom: "1px solid rgba(31,42,38,0.10)", alignItems: "center",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                <Avatar user={u} size={42}/>
                <div>
                  <div style={{ fontFamily: "Newsreader, serif", fontSize: 17, color: "#1F2A26" }}>{u.name}</div>
                  <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "rgba(31,42,38,0.55)", letterSpacing: "0.04em", marginTop: 2 }}>{roleLabel(u.role)}</div>
                </div>
              </div>
              <div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 4 }}>{lang === "es" ? "Clientes" : "Clients"}</div>
                <div style={{ fontFamily: "Newsreader, serif", fontSize: 22, color: "#1F2A26", fontWeight: 400, letterSpacing: "-0.01em" }}>{clients.length}</div>
              </div>
              <div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 4 }}>{lang === "es" ? "Servicios activos" : "Active services"}</div>
                <div style={{ fontFamily: "Newsreader, serif", fontSize: 22, color: "#1F2A26", fontWeight: 400, letterSpacing: "-0.01em" }}>{assigned.length}</div>
              </div>
              <div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 4 }}>{lang === "es" ? "Carga" : "Load"}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ flex: 1 }}>
                    <Progress value={cap} color={cap > 85 ? "#B85F3D" : "#2E8169"}/>
                  </div>
                  <span style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: cap > 85 ? "#B85F3D" : "rgba(31,42,38,0.7)", fontVariantNumeric: "tabular-nums" }}>{cap}%</span>
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <Btn kind="quiet" size="sm">{lang === "es" ? "Ver perfil" : "Profile"} →</Btn>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}

Object.assign(window, { ServiceDetailPage, BillingPage, CalendarPage, TeamPage, ScoreBlock });
