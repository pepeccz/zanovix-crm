// Mock data for the Zanovix CRM prototype.
// Designed to feel real for screenshots — Spanish PYME / mid-size companies,
// each with a believable mix of diagnostic / development / training in
// different states.

window.DATA = (() => {
  const team = [
    { id: "u-pepe",   name: "Pepe Cabeza",      role: "founder",    initials: "PC", color: "#2E8169" },
    { id: "u-marta",  name: "Marta Rivilla",    role: "consultant", initials: "MR", color: "#B85F3D" },
    { id: "u-alex",   name: "Álex Pomares",     role: "consultant", initials: "AP", color: "#1F5B49" },
    { id: "u-clara",  name: "Clara Bueno",      role: "developer",  initials: "CB", color: "#3B463F" },
    { id: "u-diego",  name: "Diego Aranda",     role: "developer",  initials: "DA", color: "#6BBF96" },
  ];

  const clients = [
    {
      id: "c-carnicas-sur", name: "Cárnicas Del Sur", sector: "Industria alimentaria",
      size: "180 empleados", region: "Sevilla", owner: "u-marta",
      stage: "active", entered: "2025-09-04",
      contacts: [
        { name: "Inés Berrocal", role: "Directora de Operaciones", email: "ines@carnicasdelsur.es" },
        { name: "Pablo Linares", role: "IT Manager",                email: "p.linares@carnicasdelsur.es" }
      ],
      mrr: 1450,
      services: ["s-csur-1", "s-csur-2", "s-csur-3"]
    },
    {
      id: "c-naviera-med", name: "Naviera Mediterránea", sector: "Logística marítima",
      size: "640 empleados", region: "Málaga", owner: "u-alex",
      stage: "active", entered: "2025-06-18",
      contacts: [
        { name: "Jorge Salinas", role: "CIO",              email: "j.salinas@navmed.com" },
        { name: "Eva Marfil",    role: "Head of Customer", email: "eva.m@navmed.com" }
      ],
      mrr: 3200,
      services: ["s-navmed-1", "s-navmed-2"]
    },
    {
      id: "c-bodegas-linares", name: "Bodegas Linares", sector: "Vinos · D.O. Málaga",
      size: "42 empleados", region: "Antequera", owner: "u-marta",
      stage: "active", entered: "2026-01-22",
      contacts: [
        { name: "Carmen Linares", role: "CEO", email: "carmen@bodegaslinares.es" }
      ],
      mrr: 580,
      services: ["s-blin-1", "s-blin-2"]
    },
    {
      id: "c-hosp-andalucia", name: "Grupo Hospitalario Andalucía", sector: "Salud",
      size: "1,240 empleados", region: "Granada", owner: "u-pepe",
      stage: "active", entered: "2024-11-30",
      contacts: [
        { name: "Dr. Andrés Morillo", role: "Dir. Médico", email: "amorillo@gha.es" },
        { name: "Lola Cárdenas",      role: "Compliance",  email: "lola.c@gha.es" }
      ],
      mrr: 4800,
      services: ["s-gha-1", "s-gha-2", "s-gha-3"]
    },
    {
      id: "c-despacho-cruz", name: "Despacho Cruz & Asociados", sector: "Servicios jurídicos",
      size: "28 empleados", region: "Madrid", owner: "u-alex",
      stage: "proposal_sent", entered: "2026-03-02",
      contacts: [{ name: "Ignacio Cruz", role: "Socio fundador", email: "icruz@despachocruz.es" }],
      mrr: 0,
      services: ["s-cruz-1"]
    },
    {
      id: "c-textil-betel", name: "Industria Textil Bétel", sector: "Manufactura textil",
      size: "95 empleados", region: "Murcia", owner: "u-marta",
      stage: "discovery_done", entered: "2026-04-11",
      contacts: [{ name: "Rosa Quero", role: "Directora general", email: "rquero@betel.es" }],
      mrr: 0,
      services: []
    },
    {
      id: "c-logistica-rios", name: "Logística Ríos", sector: "Distribución",
      size: "220 empleados", region: "Córdoba", owner: "u-alex",
      stage: "discovery_scheduled", entered: "2026-04-28",
      contacts: [{ name: "Tomás Ríos", role: "Gerente", email: "t.rios@logisticarios.es" }],
      mrr: 0,
      services: []
    },
    {
      id: "c-distri-andaluza", name: "Distribuidora Andaluza Frescos", sector: "Alimentación HORECA",
      size: "78 empleados", region: "Cádiz", owner: "u-marta",
      stage: "lead", entered: "2026-05-05",
      contacts: [{ name: "Sergio Beltrán", role: "COO", email: "sergio@daf.es" }],
      mrr: 0,
      services: []
    },
    {
      id: "c-clinica-vives", name: "Clínica Dental Vives", sector: "Salud privada",
      size: "18 empleados", region: "Málaga", owner: "u-marta",
      stage: "lead", entered: "2026-05-08",
      contacts: [{ name: "Helena Vives", role: "Propietaria", email: "h.vives@clinicavives.es" }],
      mrr: 0,
      services: []
    },
    {
      id: "c-aceites-doral", name: "Aceites Dorales", sector: "Aceite de oliva",
      size: "55 empleados", region: "Jaén", owner: "u-alex",
      stage: "lost", entered: "2025-12-01",
      contacts: [{ name: "Manuel Doral", role: "CEO", email: "m.doral@aceitesdorales.es" }],
      mrr: 0,
      services: []
    },
  ];

  // Services: every service belongs to a client. Multiple per client, in
  // different states. Each carries one price (assessment / formation) or two
  // prices (development = setup + monthly maintenance).
  const services = [
    // Cárnicas Del Sur
    { id: "s-csur-1", clientId: "c-carnicas-sur", type: "assessment", title: "AI Readiness Assessment", state: "completed",
      progress: 100, owner: "u-marta", started: "2025-09-15", ended: "2025-10-06",
      setupPrice: 8500, monthly: 0, score: 62, deliverables: 3 },
    { id: "s-csur-2", clientId: "c-carnicas-sur", type: "development", title: "Agente predicción demanda · línea charcutería", state: "maintenance",
      progress: 100, owner: "u-clara", started: "2025-10-20", ended: "2026-02-14",
      setupPrice: 28000, monthly: 950, deliverables: 7 },
    { id: "s-csur-3", clientId: "c-carnicas-sur", type: "development", title: "Asistente interno RAG · normativa sanitaria", state: "development",
      progress: 55, owner: "u-diego", started: "2026-03-10", ended: null,
      setupPrice: 18500, monthly: 500, deliverables: 4 },

    // Naviera Mediterránea
    { id: "s-navmed-1", clientId: "c-naviera-med", type: "development", title: "Plataforma RAG · documentación contratos marítimos", state: "maintenance",
      progress: 100, owner: "u-diego", started: "2025-07-01", ended: "2025-11-30",
      setupPrice: 62000, monthly: 2200, deliverables: 11 },
    { id: "s-navmed-2", clientId: "c-naviera-med", type: "development", title: "Integración SAP · agente reconciliación facturas", state: "review",
      progress: 85, owner: "u-clara", started: "2026-01-14", ended: null,
      setupPrice: 41000, monthly: 1000, deliverables: 6 },

    // Bodegas Linares
    { id: "s-blin-1", clientId: "c-bodegas-linares", type: "assessment", title: "AI Readiness Assessment", state: "completed",
      progress: 100, owner: "u-marta", started: "2026-02-02", ended: "2026-02-23",
      setupPrice: 4200, monthly: 0, score: 41, deliverables: 3 },
    { id: "s-blin-2", clientId: "c-bodegas-linares", type: "development", title: "Asistente comercial · catálogo de vinos", state: "development",
      progress: 35, owner: "u-clara", started: "2026-03-15", ended: null,
      setupPrice: 14500, monthly: 580, deliverables: 5 },

    // Hospitalario Andalucía
    { id: "s-gha-1", clientId: "c-hosp-andalucia", type: "assessment", title: "AI Readiness Assessment + Auditoría AI Act", state: "completed",
      progress: 100, owner: "u-pepe", started: "2024-12-09", ended: "2025-01-31",
      setupPrice: 18000, monthly: 0, score: 78, deliverables: 5 },
    { id: "s-gha-2", clientId: "c-hosp-andalucia", type: "development", title: "Sistema RAG · protocolos clínicos internos", state: "maintenance",
      progress: 100, owner: "u-diego", started: "2025-02-15", ended: "2025-08-30",
      setupPrice: 95000, monthly: 3200, deliverables: 14 },
    { id: "s-gha-3", clientId: "c-hosp-andalucia", type: "formation", title: "Formación directiva · gobierno de IA en sanidad", state: "scheduled",
      progress: 20, owner: "u-pepe", started: "2026-05-20", ended: "2026-06-18",
      setupPrice: 6400, monthly: 0, deliverables: 4 },

    // Despacho Cruz
    { id: "s-cruz-1", clientId: "c-despacho-cruz", type: "assessment", title: "AI Readiness Assessment · enfoque legaltech", state: "scoping",
      progress: 5, owner: "u-alex", started: null, ended: null,
      setupPrice: 5800, monthly: 0, deliverables: 3 },
  ];

  // Invoices — one-time + recurring. Mix paid / pending / overdue / draft.
  const invoices = [
    { id: "INV-2026-041", clientId: "c-carnicas-sur",    serviceId: "s-csur-3",   concept: "Asistente RAG · hito 2 de 4",            amount: 6500, status: "paid",    issued: "2026-04-15", due: "2026-04-29", method: "stripe" },
    { id: "INV-2026-040", clientId: "c-carnicas-sur",    serviceId: "s-csur-2",   concept: "Mantenimiento mensual · abril",          amount: 950,  status: "paid",    issued: "2026-04-01", due: "2026-04-15", method: "stripe", recurring: true },
    { id: "INV-2026-039", clientId: "c-naviera-med",     serviceId: "s-navmed-1", concept: "Mantenimiento RAG marítimo · abril",     amount: 2200, status: "paid",    issued: "2026-04-01", due: "2026-04-15", method: "transfer", recurring: true },
    { id: "INV-2026-038", clientId: "c-naviera-med",     serviceId: "s-navmed-2", concept: "Integración SAP · hito 3 de 4",          amount: 12000,status: "pending", issued: "2026-04-22", due: "2026-05-13", method: "transfer" },
    { id: "INV-2026-037", clientId: "c-hosp-andalucia",  serviceId: "s-gha-2",    concept: "Mantenimiento RAG clínico · abril",      amount: 3200, status: "paid",    issued: "2026-04-01", due: "2026-04-15", method: "transfer", recurring: true },
    { id: "INV-2026-036", clientId: "c-hosp-andalucia",  serviceId: "s-gha-3",    concept: "Formación directiva · sesiones 1 y 2",   amount: 3200, status: "pending", issued: "2026-04-30", due: "2026-05-21", method: "transfer" },
    { id: "INV-2026-035", clientId: "c-bodegas-linares", serviceId: "s-blin-2",   concept: "Asistente comercial · hito 1 de 3",      amount: 5200, status: "overdue", issued: "2026-03-28", due: "2026-04-18", method: "stripe" },
    { id: "INV-2026-034", clientId: "c-bodegas-linares", serviceId: "s-blin-2",   concept: "Mantenimiento · abril",                  amount: 580,  status: "paid",    issued: "2026-04-01", due: "2026-04-15", method: "stripe", recurring: true },
    { id: "INV-2026-033", clientId: "c-carnicas-sur",    serviceId: "s-csur-2",   concept: "Mantenimiento mensual · marzo",          amount: 950,  status: "paid",    issued: "2026-03-01", due: "2026-03-15", method: "stripe", recurring: true },
    { id: "INV-2026-D01", clientId: "c-despacho-cruz",   serviceId: "s-cruz-1",   concept: "Diagnóstico · primer pago (40%)",        amount: 2320, status: "draft",   issued: null,        due: null,         method: null },
  ];

  // Calendar events
  const events = [
    { id: "ev-1",  date: "2026-05-11", time: "10:00", duration: 60, title: "Discovery · Logística Ríos",                clientId: "c-logistica-rios",  attendees: ["u-alex", "u-pepe"], kind: "discovery" },
    { id: "ev-2",  date: "2026-05-11", time: "12:30", duration: 30, title: "Stand-up interno",                           clientId: null,                attendees: ["u-pepe","u-marta","u-alex","u-clara","u-diego"], kind: "internal" },
    { id: "ev-3",  date: "2026-05-11", time: "16:00", duration: 90, title: "Revisión hito · Naviera SAP",                clientId: "c-naviera-med",     attendees: ["u-clara","u-alex"], kind: "review" },
    { id: "ev-4",  date: "2026-05-12", time: "09:30", duration: 60, title: "Sesión diagnóstico · Despacho Cruz",         clientId: "c-despacho-cruz",   attendees: ["u-alex","u-pepe"], kind: "assessment" },
    { id: "ev-5",  date: "2026-05-12", time: "11:30", duration: 60, title: "Cierre propuesta · Textil Bétel",            clientId: "c-textil-betel",    attendees: ["u-marta"], kind: "proposal" },
    { id: "ev-6",  date: "2026-05-13", time: "10:00", duration: 120,title: "Formación directiva · GHA sesión 3",         clientId: "c-hosp-andalucia",  attendees: ["u-pepe"], kind: "formation" },
    { id: "ev-7",  date: "2026-05-13", time: "15:00", duration: 60, title: "Discovery · Distribuidora Andaluza",         clientId: "c-distri-andaluza", attendees: ["u-marta","u-pepe"], kind: "discovery" },
    { id: "ev-8",  date: "2026-05-14", time: "09:00", duration: 60, title: "Demo asistente RAG · Cárnicas Del Sur",      clientId: "c-carnicas-sur",    attendees: ["u-diego","u-marta"], kind: "demo" },
    { id: "ev-9",  date: "2026-05-14", time: "12:00", duration: 30, title: "Discovery · Clínica Vives",                  clientId: "c-clinica-vives",   attendees: ["u-marta"], kind: "discovery" },
    { id: "ev-10", date: "2026-05-15", time: "10:00", duration: 90, title: "Revisión score · Bodegas Linares",           clientId: "c-bodegas-linares", attendees: ["u-clara","u-marta"], kind: "review" },
  ];

  // Documents — assessment deliverables, DPAs, manuals
  const documents = [
    { id: "doc-1",  clientId: "c-carnicas-sur",   name: "Informe AI Readiness · Cárnicas Del Sur.pdf",      kind: "Diagnóstico", size: "4.2 MB", updated: "2025-10-06" },
    { id: "doc-2",  clientId: "c-carnicas-sur",   name: "DPA · Asistente RAG.pdf",                           kind: "Cumplimiento", size: "180 KB", updated: "2026-03-10" },
    { id: "doc-3",  clientId: "c-carnicas-sur",   name: "Manual operativo · Predicción demanda.pdf",        kind: "Manual",       size: "2.1 MB", updated: "2026-02-14" },
    { id: "doc-4",  clientId: "c-hosp-andalucia", name: "Informe AI Readiness · GHA.pdf",                    kind: "Diagnóstico", size: "6.8 MB", updated: "2025-01-31" },
    { id: "doc-5",  clientId: "c-hosp-andalucia", name: "Evaluación de impacto · RGPD + AI Act.pdf",         kind: "Cumplimiento", size: "920 KB", updated: "2025-02-20" },
    { id: "doc-6",  clientId: "c-bodegas-linares",name: "Informe AI Readiness · Bodegas Linares.pdf",        kind: "Diagnóstico", size: "3.4 MB", updated: "2026-02-23" },
    { id: "doc-7",  clientId: "c-naviera-med",    name: "Arquitectura RAG marítimo · v2.pdf",                kind: "Técnico",     size: "5.1 MB", updated: "2025-11-30" },
  ];

  // Pipeline stage definitions
  const stages = [
    { id: "lead",                title: { es: "Leads",                en: "Leads" } },
    { id: "discovery_scheduled", title: { es: "Discovery agendada",   en: "Discovery booked" } },
    { id: "discovery_done",      title: { es: "Discovery realizada",  en: "Discovery done" } },
    { id: "proposal_sent",       title: { es: "Propuesta enviada",    en: "Proposal sent" } },
    { id: "active",              title: { es: "En el ecosistema",     en: "In the ecosystem" } },
  ];

  return { team, clients, services, invoices, events, documents, stages };
})();

window.helpers = {
  fmtMoney(n, lang) {
    if (n == null) return "—";
    return new Intl.NumberFormat(lang === "en" ? "en-GB" : "es-ES", {
      style: "currency", currency: "EUR", maximumFractionDigits: 0
    }).format(n);
  },
  fmtDate(s, lang) {
    if (!s) return "—";
    return new Intl.DateTimeFormat(lang === "en" ? "en-GB" : "es-ES", {
      day: "2-digit", month: "short", year: "numeric"
    }).format(new Date(s + "T00:00:00"));
  },
  fmtDateShort(s, lang) {
    if (!s) return "—";
    return new Intl.DateTimeFormat(lang === "en" ? "en-GB" : "es-ES", {
      day: "2-digit", month: "short"
    }).format(new Date(s + "T00:00:00"));
  },
  byId(coll, id) { return coll.find(x => x.id === id); },
  clientOf(id) { return window.DATA.clients.find(c => c.id === id); },
  userOf(id)   { return window.DATA.team.find(u => u.id === id); },
  serviceOf(id){ return window.DATA.services.find(s => s.id === id); },
};
