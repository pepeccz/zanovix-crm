// Shared UI primitives for the Zanovix CRM.
// Editorial in the chrome (serif titles, italic emphasis, hairlines, terra
// marginalia) — functional in the body (Inter dense tables, status pills).
//
// Globals exposed at end of file.

const { useState, useEffect, useMemo, useRef, createContext, useContext } = React;

/* ------------------------------------------------------------------
   Context: language + perspective + role
   ------------------------------------------------------------------ */
const AppCtx = createContext(null);
function useApp() { return useContext(AppCtx); }
function useT() {
  const { lang } = useApp();
  return (key) => (window.I18N[lang] && window.I18N[lang][key]) || key;
}

/* ------------------------------------------------------------------
   Tiny router — hash based
   ------------------------------------------------------------------ */
function useRoute() {
  const [hash, setHash] = useState(window.location.hash || "#/admin");
  useEffect(() => {
    const onHash = () => setHash(window.location.hash || "#/admin");
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  const path = hash.replace(/^#/, "") || "/admin";
  const parts = path.split("/").filter(Boolean);
  return { path, parts };
}
function navigate(path) {
  window.location.hash = "#" + path;
}

/* ------------------------------------------------------------------
   Icons — minimal 1.5px-stroke line icons (no library, very small set)
   ------------------------------------------------------------------ */
function Icon({ name, size = 16 }) {
  const props = { width: size, height: size, viewBox: "0 0 24 24", fill: "none",
                  stroke: "currentColor", strokeWidth: 1.5, strokeLinecap: "round", strokeLinejoin: "round" };
  switch (name) {
    case "dashboard": return <svg {...props}><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>;
    case "pipeline":  return <svg {...props}><path d="M4 6h6M4 12h10M4 18h7"/><circle cx="18" cy="6" r="2"/><circle cx="18" cy="12" r="2"/><circle cx="18" cy="18" r="2"/></svg>;
    case "clients":   return <svg {...props}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>;
    case "billing":   return <svg {...props}><rect x="3" y="5" width="18" height="14" rx="1"/><path d="M3 10h18M7 15h4"/></svg>;
    case "calendar":  return <svg {...props}><rect x="3" y="4" width="18" height="17" rx="1"/><path d="M3 9h18M8 2v4M16 2v4"/></svg>;
    case "team":      return <svg {...props}><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>;
    case "settings":  return <svg {...props}><circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/></svg>;
    case "doc":       return <svg {...props}><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/></svg>;
    case "diag":      return <svg {...props}><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>;
    case "support":   return <svg {...props}><path d="M21 11.5a8.4 8.4 0 0 1-9 8.5l-5 2 1.5-4.5A8.4 8.4 0 1 1 21 11.5z"/></svg>;
    case "chat":      return <svg {...props}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>;
    case "arrow":     return <svg {...props}><path d="M5 12h14M13 5l7 7-7 7"/></svg>;
    case "plus":      return <svg {...props}><path d="M12 5v14M5 12h14"/></svg>;
    case "filter":    return <svg {...props}><path d="M3 5h18l-7 9v5l-4 2v-7z"/></svg>;
    case "down":      return <svg {...props}><path d="m6 9 6 6 6-6"/></svg>;
    case "check":     return <svg {...props}><path d="M5 12l4 4L19 6"/></svg>;
    case "more":      return <svg {...props}><circle cx="12" cy="12" r="1"/><circle cx="5" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></svg>;
    case "google":    return <svg width={size} height={size} viewBox="0 0 24 24"><path fill="#EA4335" d="M12 11v3.2h5.3c-.2 1.2-1.5 3.5-5.3 3.5-3.2 0-5.8-2.6-5.8-5.7s2.6-5.7 5.8-5.7c1.8 0 3 .8 3.7 1.4l2.5-2.4C16.5 3.7 14.5 3 12 3 6.9 3 3 6.9 3 12s3.9 9 9 9c5.2 0 8.6-3.6 8.6-8.8 0-.6 0-1-.1-1.2z"/></svg>;
    case "stripe":    return <svg width={size} height={size} viewBox="0 0 24 24" fill="#635BFF"><path d="M13.5 9.6c0-.5.4-.7 1-.7 1 0 2.2.3 3.2.8V6.5c-1.1-.4-2.2-.6-3.2-.6-2.6 0-4.4 1.4-4.4 3.7 0 3.6 4.9 3 4.9 4.6 0 .6-.5.8-1.2.8-1.1 0-2.5-.5-3.6-1.1v3.2c1.2.5 2.5.7 3.6.7 2.7 0 4.5-1.3 4.5-3.7 0-3.9-4.8-3.2-4.8-4.5z"/></svg>;
    case "flower":    return <svg width={size} height={size} viewBox="0 0 100 100"><use href="#flower-dark"/></svg>;
    case "x":         return <svg {...props}><path d="M18 6 6 18M6 6l12 12"/></svg>;
    case "ext":       return <svg {...props}><path d="M14 4h6v6M10 14 20 4M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/></svg>;
    default: return null;
  }
}

/* ------------------------------------------------------------------
   Status pill — dense, Inter, color-coded
   ------------------------------------------------------------------ */
function StatusPill({ status, size = "sm" }) {
  const t = useT();
  const map = {
    // pipeline
    lead:                { bg: "rgba(31,42,38,0.06)",  fg: "#3B463F",   dot: "#9aa39b" },
    discovery_scheduled: { bg: "rgba(184,95,61,0.10)", fg: "#B85F3D",   dot: "#B85F3D" },
    discovery_done:      { bg: "rgba(184,95,61,0.10)", fg: "#8a4528",   dot: "#B85F3D" },
    proposal_sent:       { bg: "rgba(46,129,105,0.12)",fg: "#1F5B49",   dot: "#2E8169" },
    active:              { bg: "rgba(46,129,105,0.16)",fg: "#173E32",   dot: "#2E8169" },
    lost:                { bg: "rgba(31,42,38,0.06)",  fg: "rgba(31,42,38,0.5)", dot: "#bbb" },
    // service states
    scoping:             { bg: "rgba(31,42,38,0.06)",  fg: "#3B463F",   dot: "#9aa39b" },
    development:         { bg: "rgba(46,129,105,0.10)",fg: "#1F5B49",   dot: "#2E8169" },
    review:              { bg: "rgba(184,95,61,0.10)", fg: "#B85F3D",   dot: "#B85F3D" },
    delivered:           { bg: "rgba(46,129,105,0.16)",fg: "#173E32",   dot: "#2E8169" },
    maintenance:         { bg: "rgba(46,129,105,0.10)",fg: "#1F5B49",   dot: "#6BBF96" },
    paused:              { bg: "rgba(31,42,38,0.06)",  fg: "rgba(31,42,38,0.55)", dot: "#bbb" },
    scheduled:           { bg: "rgba(184,95,61,0.10)", fg: "#B85F3D",   dot: "#B85F3D" },
    completed:           { bg: "rgba(46,129,105,0.16)",fg: "#173E32",   dot: "#2E8169" },
    in_progress:         { bg: "rgba(46,129,105,0.10)",fg: "#1F5B49",   dot: "#2E8169" },
    // invoices
    paid:                { bg: "rgba(46,129,105,0.16)",fg: "#173E32",   dot: "#2E8169" },
    pending:             { bg: "rgba(184,95,61,0.10)", fg: "#B85F3D",   dot: "#B85F3D" },
    overdue:             { bg: "rgba(204,60,40,0.12)", fg: "#a8341f",   dot: "#cc3c28" },
    draft:               { bg: "rgba(31,42,38,0.06)",  fg: "rgba(31,42,38,0.55)", dot: "#bbb" },
  };
  const s = map[status] || map.lead;
  return (
    <span className="zx-pill" style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: size === "sm" ? "2px 8px" : "4px 10px",
      background: s.bg, color: s.fg,
      fontFamily: "Inter, sans-serif", fontSize: 11.5, fontWeight: 500,
      letterSpacing: "0.02em", borderRadius: 2, whiteSpace: "nowrap",
    }}>
      <span style={{ width: 5, height: 5, borderRadius: 999, background: s.dot, display: "inline-block" }}/>
      {t("status." + status)}
    </span>
  );
}

/* ------------------------------------------------------------------
   Service-type badge
   ------------------------------------------------------------------ */
function ServiceTypeBadge({ type }) {
  const t = useT();
  const map = {
    assessment:  { bg: "rgba(46,129,105,0.10)", fg: "#1F5B49", letter: "D" },
    development: { bg: "rgba(31,42,38,0.08)",   fg: "#1F2A26", letter: "S" },
    formation:   { bg: "rgba(184,95,61,0.10)",  fg: "#B85F3D", letter: "F" },
  };
  const s = map[type] || map.assessment;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 8,
      fontFamily: "Inter, sans-serif", fontSize: 11.5,
      letterSpacing: "0.02em", color: s.fg,
    }}>
      <span style={{
        width: 18, height: 18, borderRadius: 2, background: s.bg, color: s.fg,
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        fontFamily: "Newsreader, serif", fontStyle: "italic", fontWeight: 500, fontSize: 12,
      }}>{s.letter}</span>
      {t("svc." + type)}
    </span>
  );
}

/* ------------------------------------------------------------------
   Avatar (user initials in their color)
   ------------------------------------------------------------------ */
function Avatar({ user, size = 24, label = false }) {
  if (!user) return null;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
      <span style={{
        width: size, height: size, borderRadius: 999,
        background: user.color, color: "#F4F1EA",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        fontFamily: "Inter, sans-serif", fontSize: size <= 22 ? 9.5 : 11,
        fontWeight: 600, letterSpacing: "0.04em",
      }}>{user.initials}</span>
      {label && <span style={{ fontFamily: "Inter, sans-serif", fontSize: 13, color: "#3B463F" }}>{user.name}</span>}
    </span>
  );
}
function AvatarStack({ users, size = 22 }) {
  return (
    <span style={{ display: "inline-flex" }}>
      {users.map((u, i) => (
        <span key={u.id} style={{
          marginLeft: i === 0 ? 0 : -6, zIndex: users.length - i,
          outline: "1.5px solid #F4F1EA",
        }}>
          <Avatar user={u} size={size}/>
        </span>
      ))}
    </span>
  );
}

/* ------------------------------------------------------------------
   Buttons
   ------------------------------------------------------------------ */
function Btn({ children, kind = "ghost", onClick, icon, size = "md", disabled = false }) {
  const styles = {
    primary: { bg: "#1F2A26", fg: "#F4F1EA", border: "1px solid #1F2A26" },
    accent:  { bg: "#2E8169", fg: "#F4F1EA", border: "1px solid #2E8169" },
    ghost:   { bg: "transparent", fg: "#1F2A26", border: "1px solid rgba(31,42,38,0.18)" },
    quiet:   { bg: "transparent", fg: "#3B463F", border: "1px solid transparent" },
  };
  const s = styles[kind];
  const sizing = size === "sm"
    ? { padding: "5px 10px", fontSize: 12 }
    : { padding: "9px 14px", fontSize: 13 };
  return (
    <button type="button" onClick={onClick} disabled={disabled}
      style={{
        display: "inline-flex", alignItems: "center", gap: 8,
        background: s.bg, color: s.fg, border: s.border,
        borderRadius: 3, cursor: disabled ? "not-allowed" : "pointer",
        fontFamily: "Inter, sans-serif", fontWeight: 500, letterSpacing: "0.01em",
        opacity: disabled ? 0.5 : 1,
        transition: "background 150ms, border-color 150ms, color 150ms",
        ...sizing
      }}>
      {icon && <Icon name={icon} size={14}/>}
      {children}
    </button>
  );
}

/* ------------------------------------------------------------------
   Page header — editorial serif w/ italic em + Inter lede meta
   ------------------------------------------------------------------ */
function PageHeader({ eyebrow, title, lede, right }) {
  return (
    <header style={{
      display: "flex", alignItems: "flex-end", justifyContent: "space-between",
      gap: 32, padding: "32px 40px 28px", borderBottom: "1px solid rgba(31,42,38,0.14)",
    }}>
      <div style={{ maxWidth: 720 }}>
        {eyebrow && (
          <div style={{
            fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 14,
            color: "#2E8169", marginBottom: 10,
          }}>— {eyebrow}</div>
        )}
        <h1 style={{
          fontFamily: "Newsreader, serif", fontWeight: 400,
          fontSize: 38, lineHeight: 1.1, letterSpacing: "-0.02em",
          color: "#1F2A26", textWrap: "balance", margin: 0,
        }} dangerouslySetInnerHTML={{ __html: title }}/>
        {lede && (
          <p style={{
            marginTop: 12, fontFamily: "Newsreader, serif", fontStyle: "italic",
            fontSize: 16, lineHeight: 1.5, color: "rgba(31,42,38,0.6)", maxWidth: 60 + "ch",
          }}>{lede}</p>
        )}
      </div>
      {right && <div style={{ display: "flex", gap: 10, alignItems: "center" }}>{right}</div>}
    </header>
  );
}

/* ------------------------------------------------------------------
   Section block (a card-less panel with optional title row)
   ------------------------------------------------------------------ */
function Section({ title, meta, right, children, padded = true, margin }) {
  return (
    <section style={{ padding: padded ? "24px 40px 28px" : 0, borderBottom: "1px solid rgba(31,42,38,0.14)" }}>
      {(title || right || margin) && (
        <div style={{ display: "grid", gridTemplateColumns: margin ? "1fr 240px" : "1fr", gap: 32, marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16 }}>
            <div style={{ display: "flex", alignItems: "baseline", gap: 14 }}>
              {title && (
                <h2 style={{
                  fontFamily: "Newsreader, serif", fontWeight: 500, fontSize: 20,
                  letterSpacing: "-0.015em", color: "#1F2A26", margin: 0,
                }} dangerouslySetInnerHTML={{ __html: title }}/>
              )}
              {meta && <span style={{
                fontFamily: "Inter, sans-serif", fontSize: 11, letterSpacing: "0.18em",
                textTransform: "uppercase", color: "rgba(31,42,38,0.5)",
              }}>{meta}</span>}
            </div>
            {right}
          </div>
          {margin && (
            <div style={{
              fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 13,
              color: "#B85F3D", lineHeight: 1.4, textAlign: "right",
              paddingRight: 12, borderRight: "1px solid #B85F3D", opacity: 0.85,
              alignSelf: "center",
            }}>{margin}</div>
          )}
        </div>
      )}
      {children}
    </section>
  );
}

/* ------------------------------------------------------------------
   Dense table
   ------------------------------------------------------------------ */
function Table({ columns, rows, onRowClick }) {
  return (
    <div style={{ borderTop: "1px solid rgba(31,42,38,0.14)" }}>
      {/* header */}
      <div style={{
        display: "grid",
        gridTemplateColumns: columns.map(c => c.w || "1fr").join(" "),
        gap: 16, padding: "10px 40px", background: "rgba(236,230,214,0.4)",
        borderBottom: "1px solid rgba(31,42,38,0.14)",
        fontFamily: "Inter, sans-serif", fontSize: 11, letterSpacing: "0.12em",
        textTransform: "uppercase", color: "rgba(31,42,38,0.55)", fontWeight: 500,
      }}>
        {columns.map(c => (
          <div key={c.key} style={{ textAlign: c.align || "left" }}>{c.label}</div>
        ))}
      </div>
      {/* rows */}
      {rows.map((row, i) => (
        <div key={row.id || i}
          onClick={() => onRowClick && onRowClick(row)}
          style={{
            display: "grid",
            gridTemplateColumns: columns.map(c => c.w || "1fr").join(" "),
            gap: 16, padding: "11px 40px", alignItems: "center",
            borderBottom: "1px solid rgba(31,42,38,0.08)",
            fontFamily: "Inter, sans-serif", fontSize: 13, color: "#1F2A26",
            cursor: onRowClick ? "pointer" : "default",
            transition: "background 120ms",
          }}
          onMouseEnter={(e) => { if (onRowClick) e.currentTarget.style.background = "rgba(46,129,105,0.04)"; }}
          onMouseLeave={(e) => { if (onRowClick) e.currentTarget.style.background = "transparent"; }}
        >
          {columns.map(c => (
            <div key={c.key} style={{ textAlign: c.align || "left", minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: c.wrap ? "normal" : "nowrap" }}>
              {c.render ? c.render(row) : row[c.key]}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------
   KPI card — no fill, hairline only, big numeric, italic delta
   ------------------------------------------------------------------ */
function KPI({ label, value, delta, footnote }) {
  return (
    <div style={{ padding: "20px 24px", borderRight: "1px solid rgba(31,42,38,0.14)" }}>
      <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, letterSpacing: "0.18em",
        textTransform: "uppercase", color: "rgba(31,42,38,0.55)", marginBottom: 12 }}>{label}</div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 12 }}>
        <span style={{
          fontFamily: "Newsreader, serif", fontWeight: 400, fontSize: 38,
          letterSpacing: "-0.02em", color: "#1F2A26", lineHeight: 1,
        }}>{value}</span>
        {delta && (
          <span style={{
            fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 14,
            color: delta.startsWith("−") || delta.startsWith("-") ? "#B85F3D" : "#2E8169",
          }}>{delta}</span>
        )}
      </div>
      {footnote && (
        <div style={{
          marginTop: 8, fontFamily: "Newsreader, serif", fontStyle: "italic",
          fontSize: 13, color: "rgba(31,42,38,0.55)", lineHeight: 1.35,
        }}>{footnote}</div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------
   Progress bar — hairline track + ink fill
   ------------------------------------------------------------------ */
function Progress({ value, color = "#1F2A26", height = 4 }) {
  return (
    <div style={{ width: "100%", height, background: "rgba(31,42,38,0.10)", borderRadius: 999 }}>
      <div style={{ width: `${value}%`, height: "100%", background: color, borderRadius: 999 }}/>
    </div>
  );
}

/* ------------------------------------------------------------------
   Toolbar — filter row above tables
   ------------------------------------------------------------------ */
function Toolbar({ children, right }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "14px 40px", gap: 16,
      borderBottom: "1px solid rgba(31,42,38,0.10)",
    }}>
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>{children}</div>
      {right && <div style={{ display: "flex", gap: 8 }}>{right}</div>}
    </div>
  );
}
function FilterChip({ active, onClick, children, count }) {
  return (
    <button type="button" onClick={onClick} style={{
      display: "inline-flex", alignItems: "center", gap: 8,
      padding: "5px 11px", borderRadius: 999, cursor: "pointer",
      border: active ? "1px solid #1F2A26" : "1px solid rgba(31,42,38,0.18)",
      background: active ? "#1F2A26" : "transparent",
      color: active ? "#F4F1EA" : "#3B463F",
      fontFamily: "Inter, sans-serif", fontSize: 12, fontWeight: 500,
      transition: "all 150ms",
    }}>
      {children}
      {count != null && (
        <span style={{
          fontVariantNumeric: "tabular-nums",
          opacity: 0.7, fontSize: 11,
        }}>{count}</span>
      )}
    </button>
  );
}

/* expose */
Object.assign(window, {
  AppCtx, useApp, useT, useRoute, navigate,
  Icon, StatusPill, ServiceTypeBadge, Avatar, AvatarStack, Btn,
  PageHeader, Section, Table, KPI, Progress, Toolbar, FilterChip,
});
