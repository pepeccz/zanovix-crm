// App shell — sidebar + topbar with view switch (internal/client),
// language toggle (ES/EN) and role switch. Renders the routed page.

const { useState: useStateShell } = React;

function Sidebar({ side = "internal" }) {
  const t = useT();
  const { route, navigate: nav } = { route: useRoute(), navigate };
  const current = route.path;

  const internalNav = [
    { path: "/admin",          icon: "dashboard", key: "nav.dashboard" },
    { path: "/admin/pipeline", icon: "pipeline",  key: "nav.pipeline" },
    { path: "/admin/clients",  icon: "clients",   key: "nav.clients" },
    { path: "/admin/services", icon: "doc",       key: "nav.services" },
    { path: "/admin/billing",  icon: "billing",   key: "nav.billing" },
    { path: "/admin/calendar", icon: "calendar",  key: "nav.calendar" },
    { path: "/admin/team",     icon: "team",      key: "nav.team" },
  ];
  const clientNav = [
    { path: "/client",            icon: "dashboard", key: "nav.dashboard" },
    { path: "/client/diagnostic", icon: "diag",      key: "nav.my_diagnostic" },
    { path: "/client/projects",   icon: "doc",       key: "nav.projects" },
    { path: "/client/formation",  icon: "team",      key: "nav.formation" },
    { path: "/client/meetings",   icon: "calendar",  key: "nav.meetings" },
    { path: "/client/billing",    icon: "billing",   key: "nav.billing" },
    { path: "/client/documents",  icon: "doc",       key: "nav.documents" },
    { path: "/client/chat",       icon: "chat",      key: "nav.chat" },
    { path: "/client/support",    icon: "support",   key: "nav.support" },
  ];
  const items = side === "internal" ? internalNav : clientNav;

  const isActive = (p) => {
    if (p === "/admin" || p === "/client") return current === p;
    return current === p || current.startsWith(p + "/");
  };

  return (
    <aside style={{
      width: 232, flexShrink: 0, height: "100vh", position: "sticky", top: 0,
      borderRight: "1px solid rgba(31,42,38,0.14)",
      background: "rgba(236,230,214,0.4)",
      display: "flex", flexDirection: "column",
    }}>
      {/* brand */}
      <div style={{ padding: "20px 22px 18px", borderBottom: "1px solid rgba(31,42,38,0.10)" }}>
        <a href={"#" + (side === "internal" ? "/admin" : "/client")} style={{
          display: "flex", alignItems: "center", gap: 10, textDecoration: "none",
        }}>
          <svg width="22" height="22"><use href="#flower-dark"/></svg>
          <span style={{
            fontFamily: "Inter, sans-serif", fontSize: 13, fontWeight: 600,
            letterSpacing: "0.18em", textTransform: "uppercase", color: "#1F2A26",
          }}>Zanovix</span>
          <span style={{
            marginLeft: "auto",
            fontFamily: "Newsreader, serif", fontStyle: "italic",
            fontSize: 12, color: "rgba(31,42,38,0.55)",
          }}>CRM</span>
        </a>
      </div>

      {/* nav */}
      <nav style={{ padding: "16px 12px", flex: 1, overflowY: "auto" }}>
        {items.map(it => (
          <a key={it.path} href={"#" + it.path}
            style={{
              display: "flex", alignItems: "center", gap: 12,
              padding: "8px 12px", borderRadius: 2,
              fontFamily: "Inter, sans-serif", fontSize: 13,
              fontWeight: isActive(it.path) ? 600 : 400,
              color: isActive(it.path) ? "#1F2A26" : "#3B463F",
              background: isActive(it.path) ? "rgba(46,129,105,0.10)" : "transparent",
              borderLeft: isActive(it.path) ? "2px solid #2E8169" : "2px solid transparent",
              textDecoration: "none", marginBottom: 2,
              transition: "background 150ms, color 150ms",
            }}>
            <Icon name={it.icon} size={15}/>
            {t(it.key)}
          </a>
        ))}
      </nav>

      {/* footer block — integration health */}
      <div style={{ padding: "14px 18px", borderTop: "1px solid rgba(31,42,38,0.10)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
          <Icon name="google" size={14}/>
          <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)", letterSpacing: "0.04em" }}>
            {t("google.synced")}
          </span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Icon name="stripe" size={14}/>
          <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)", letterSpacing: "0.04em" }}>
            {t("stripe.synced")}
          </span>
        </div>
      </div>
    </aside>
  );
}

function Topbar({ side, currentUser }) {
  const t = useT();
  const { lang, setLang, perspective, setPerspective, role, setRole } = useApp();

  return (
    <div style={{
      position: "sticky", top: 0, zIndex: 40,
      background: "color-mix(in srgb, #F4F1EA 92%, transparent)",
      backdropFilter: "blur(12px)",
      WebkitBackdropFilter: "blur(12px)",
      borderBottom: "1px solid rgba(31,42,38,0.14)",
      padding: "12px 40px",
      display: "flex", alignItems: "center", gap: 16,
    }}>
      {/* search */}
      <div style={{
        display: "flex", alignItems: "center", gap: 8, flex: 1, maxWidth: 460,
        padding: "7px 12px", border: "1px solid rgba(31,42,38,0.14)", borderRadius: 3,
        background: "rgba(244,241,234,0.7)",
      }}>
        <Icon name="diag" size={14}/>
        <input type="text" placeholder={t("shell.search")}
          style={{
            flex: 1, border: "none", outline: "none", background: "transparent",
            fontFamily: "Inter, sans-serif", fontSize: 13, color: "#1F2A26",
          }}/>
        <kbd style={{
          fontFamily: "Inter, sans-serif", fontSize: 10.5, padding: "2px 5px",
          border: "1px solid rgba(31,42,38,0.18)", borderRadius: 2,
          color: "rgba(31,42,38,0.55)",
        }}>⌘K</kbd>
      </div>

      {/* perspective switch */}
      <div style={{
        display: "inline-flex", border: "1px solid rgba(31,42,38,0.14)", borderRadius: 3,
        overflow: "hidden",
      }}>
        {[
          { id: "internal", label: t("shell.view_internal"), href: "#/admin" },
          { id: "client",   label: t("shell.view_client"),   href: "#/client" },
        ].map(opt => (
          <a key={opt.id} href={opt.href}
            onClick={() => setPerspective(opt.id)}
            style={{
              padding: "6px 12px",
              fontFamily: "Inter, sans-serif", fontSize: 12, fontWeight: 500,
              background: perspective === opt.id ? "#1F2A26" : "transparent",
              color: perspective === opt.id ? "#F4F1EA" : "#3B463F",
              textDecoration: "none",
              transition: "all 150ms",
            }}>
            {opt.label}
          </a>
        ))}
      </div>

      {/* language toggle */}
      <div style={{
        display: "inline-flex", border: "1px solid rgba(31,42,38,0.14)", borderRadius: 3,
        overflow: "hidden", fontFamily: "Inter, sans-serif", fontSize: 11, letterSpacing: "0.12em",
      }}>
        {["es", "en"].map(l => (
          <button key={l} type="button" onClick={() => setLang(l)} style={{
            padding: "6px 10px", cursor: "pointer",
            background: lang === l ? "#2E8169" : "transparent",
            color: lang === l ? "#F4F1EA" : "#3B463F",
            border: "none", textTransform: "uppercase", fontWeight: 600,
          }}>{l}</button>
        ))}
      </div>

      {/* role selector (only on internal) */}
      {side === "internal" && (
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{
            fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 13,
            color: "rgba(31,42,38,0.55)",
          }}>—</span>
          <select value={role} onChange={(e) => setRole(e.target.value)}
            style={{
              padding: "6px 8px", border: "1px solid rgba(31,42,38,0.14)", borderRadius: 3,
              fontFamily: "Inter, sans-serif", fontSize: 12, color: "#1F2A26",
              background: "transparent",
            }}>
            <option value="founder">Admin · Pepe</option>
            <option value="consultant">Consultor</option>
          </select>
        </div>
      )}

      {/* current user avatar */}
      <Avatar user={currentUser} size={28} label={false}/>
    </div>
  );
}

function AppShell({ children, side, currentUser }) {
  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <Sidebar side={side}/>
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        <Topbar side={side} currentUser={currentUser}/>
        <main style={{ flex: 1 }}>{children}</main>
      </div>
    </div>
  );
}

Object.assign(window, { AppShell, Sidebar, Topbar });
