// Client portal pages: Dashboard, Diagnostic detail, Projects, Invoices, Documents, Calendar, Messages, Support.

const { useState: useStateCP, useMemo: useMemoCP } = React;
const DC = window.DATA;
const { fmtMoney: fmtMoneyC, fmtDate: fmtDateC, fmtDateShort: fmtDateShortC, userOf: userOfC, clientOf: clientOfC, serviceOf: serviceOfC } = window.helpers;

// "Logged-in" client for the portal demo:
const PORTAL_CLIENT_ID = "c-naviera-med";

function getPortalClient() {
  return clientOfC(PORTAL_CLIENT_ID);
}

/* ================================================================
   CLIENT DASHBOARD
   ================================================================ */
function PortalDashboardPage() {
  const t = useT();
  const { lang } = useApp();
  const c = getPortalClient();
  const services = c.services.map(serviceOfC).filter(Boolean);
  const invoices = DC.invoices.filter(i => i.clientId === c.id);
  const outstanding = invoices.filter(i => ["pending","overdue"].includes(i.status));
  const events = DC.events.filter(e => e.clientId === c.id);
  const docs = DC.documents.filter(d => d.clientId === c.id);

  const contact = c.contacts[0];

  return (
    <>
      {/* Personal welcome */}
      <header style={{ padding: "32px 40px 28px", borderBottom: "1px solid rgba(31,42,38,0.14)" }}>
        <div style={{
          fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 14,
          color: "#2E8169", marginBottom: 6,
        }}>— {lang === "es" ? `hola, ${contact.name.split(" ")[0]}` : `hello, ${contact.name.split(" ")[0]}`}</div>
        <h1 style={{
          fontFamily: "Newsreader, serif", fontWeight: 400, fontSize: 48,
          letterSpacing: "-0.02em", lineHeight: 1.05, color: "#1F2A26",
          margin: "0 0 16px", maxWidth: 880,
        }}>
          {lang === "es" ? <>Esto es lo que llevamos contigo en <em style={{ fontStyle: "italic", color: "#2E8169", fontWeight: 300 }}>el ecosistema</em>.</> :
                          <>Here's what we have together inside <em style={{ fontStyle: "italic", color: "#2E8169", fontWeight: 300 }}>the ecosystem</em>.</>}
        </h1>
        <p style={{
          fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 18,
          color: "rgba(31,42,38,0.6)", maxWidth: 720, lineHeight: 1.5, margin: 0,
        }}>
          {lang === "es"
            ? "Tres servicios en curso, una propuesta pendiente y una conversación abierta con tu equipo. Sin sorpresas."
            : "Three services running, one proposal pending and an open conversation with your team. No surprises."}
        </p>
      </header>

      {/* Quick stats strip */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)",
        borderBottom: "1px solid rgba(31,42,38,0.14)", padding: "0 16px" }}>
        <KPI label={lang === "es" ? "Servicios activos" : "Active services"} value={services.length}
          footnote={lang === "es" ? "Diagnóstico cerrado · 1 desarrollo · 1 formación." : "Diagnostic closed · 1 development · 1 training."}/>
        <KPI label={lang === "es" ? "Próxima reunión" : "Next meeting"}
          value={events[0] ? fmtDateShortC(events[0].date, lang) : "—"}
          footnote={events[0] ? `${events[0].time} · ${events[0].title}` : "—"}/>
        <KPI label={lang === "es" ? "Pendiente de pago" : "Outstanding"}
          value={outstanding.length > 0 ? fmtMoneyC(outstanding.reduce((s,i)=>s+i.amount,0), lang) : "—"}
          footnote={outstanding.length > 0 ? (lang === "es" ? `${outstanding.length} factura · vence pronto` : `${outstanding.length} invoice · due soon`) : (lang === "es" ? "Todo al día." : "All paid.")}/>
        <KPI label={lang === "es" ? "Documentos nuevos" : "New documents"} value={"2"}
          footnote={lang === "es" ? "Esta semana. Sin abrir." : "This week. Unread."}/>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px" }}>
        <div style={{ borderRight: "1px solid rgba(31,42,38,0.14)" }}>
          {/* Services */}
          <Section
            title={lang === "es" ? `Tus <em style="font-style:italic;color:#2E8169;font-weight:400">servicios</em>` : `Your <em style="font-style:italic;color:#2E8169;font-weight:400">services</em>`}
            right={<a href="#/portal/services" style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "#2E8169", borderBottom: "1px solid #2E8169" }}>{lang === "es" ? "Ver todos" : "View all"} →</a>}
          >
            <div>
              {services.map(s => <PortalServiceCard key={s.id} service={s}/>)}
            </div>
          </Section>

          {/* Activity from the team */}
          <Section title={lang === "es" ? "Lo último de tu equipo" : "Latest from your team"} padded={true}>
            <PortalActivity/>
          </Section>
        </div>

        <aside style={{ padding: "24px 28px" }}>
          <SidePanel title={lang === "es" ? "Tu equipo Zanovix" : "Your Zanovix team"}>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {[userOfC(c.owner), userOfC("u-diego"), userOfC("u-pepe")].map(u => {
                const titleMap = {
                  es: { founder: "Fundador", consultant: "Consultor", developer: "Desarrollador", pm: "Project Manager" },
                  en: { founder: "Founder",  consultant: "Consultant", developer: "Developer",   pm: "Project Manager" },
                };
                const title = (titleMap[lang] && titleMap[lang][u.role]) || u.role;
                return (
                  <div key={u.id} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <Avatar user={u} size={28}/>
                    <div>
                      <div style={{ fontFamily: "Newsreader, serif", fontSize: 14, color: "#1F2A26" }}>{u.name}</div>
                      <div style={{ fontFamily: "Inter, sans-serif", fontSize: 10.5, color: "rgba(31,42,38,0.55)", letterSpacing: "0.04em" }}>{title}</div>
                    </div>
                  </div>
                );
              })}
            </div>
            <a href="#/portal/messages" style={{
              display: "inline-block", marginTop: 14,
              fontFamily: "Inter, sans-serif", fontSize: 12, color: "#2E8169",
              borderBottom: "1px solid #2E8169", paddingBottom: 1,
            }}>{lang === "es" ? "Abrir conversación" : "Open conversation"} →</a>
          </SidePanel>

          <SidePanel title={lang === "es" ? "Próximas reuniones" : "Upcoming meetings"}>
            {events.slice(0, 3).map((ev, i) => (
              <div key={ev.id} style={{
                padding: "10px 0",
                borderBottom: i === Math.min(events.length, 3) - 1 ? "none" : "1px solid rgba(31,42,38,0.10)",
              }}>
                <div style={{ fontFamily: "Newsreader, serif", fontSize: 14, color: "#1F2A26" }}>{ev.title}</div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.6)", marginTop: 3 }}>
                  {fmtDateShortC(ev.date, lang)} · {ev.time} · {ev.duration}min
                </div>
              </div>
            ))}
          </SidePanel>

          <SidePanel title={lang === "es" ? "Documentos recientes" : "Recent documents"}>
            {docs.slice(0, 4).map(d => (
              <a key={d.id} href="#" style={{
                display: "flex", justifyContent: "space-between", alignItems: "center",
                padding: "8px 0", borderBottom: "1px solid rgba(31,42,38,0.08)", textDecoration: "none",
              }}>
                <div>
                  <div style={{ fontFamily: "Inter, sans-serif", fontSize: 12.5, color: "#1F2A26" }}>{d.name}</div>
                  <div style={{ fontFamily: "Inter, sans-serif", fontSize: 10.5, color: "rgba(31,42,38,0.55)", marginTop: 2 }}>{d.kind} · {d.size}</div>
                </div>
                <Icon name="ext" size={13}/>
              </a>
            ))}
          </SidePanel>
        </aside>
      </div>
    </>
  );
}

function PortalServiceCard({ service }) {
  const { lang } = useApp();
  const t = useT();
  return (
    <a href={`#/portal/services/${service.id}`} style={{
      display: "grid", gridTemplateColumns: "160px 1fr 130px",
      gap: 24, alignItems: "center", padding: "20px 0",
      borderBottom: "1px solid rgba(31,42,38,0.10)",
      textDecoration: "none", color: "inherit",
    }}>
      <ServiceTypeBadge type={service.type}/>
      <div>
        <div style={{ fontFamily: "Newsreader, serif", fontSize: 17, color: "#1F2A26", lineHeight: 1.3, marginBottom: 8 }}>{service.title}</div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ flex: 1, maxWidth: 320 }}>
            <Progress value={service.progress} color={service.type === "assessment" ? "#2E8169" : service.type === "formation" ? "#B85F3D" : "#1F2A26"}/>
          </div>
          <span style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(31,42,38,0.6)", fontVariantNumeric: "tabular-nums" }}>{service.progress}%</span>
          <span style={{ fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 13, color: "rgba(31,42,38,0.55)" }}>
            {service.state === "completed" ? (lang === "es" ? "completado" : "completed") :
             service.state === "running"   ? (lang === "es" ? "en marcha"   : "in progress") :
             service.state === "planned"   ? (lang === "es" ? "programado"  : "scheduled") :
             service.state}
          </span>
        </div>
      </div>
      <StatusPill status={service.state}/>
    </a>
  );
}

function PortalActivity() {
  const { lang } = useApp();
  const items = lang === "es" ? [
    { dot: "#2E8169", date: "2026-05-09", text: "Diego compartió contigo el documento técnico v0.3.", who: "Diego Sanz" },
    { dot: "#1F2A26", date: "2026-05-07", text: "Pago recibido — INV-2026-041, gracias.", who: "Sistema" },
    { dot: "#B85F3D", date: "2026-05-04", text: "Clara dejó comentarios sobre el hito 2.", who: "Clara Mendoza" },
    { dot: "#2E8169", date: "2026-04-28", text: "Resumen de la reunión de seguimiento ya disponible.", who: "Clara Mendoza" },
  ] : [
    { dot: "#2E8169", date: "2026-05-09", text: "Diego shared the technical doc v0.3 with you.", who: "Diego Sanz" },
    { dot: "#1F2A26", date: "2026-05-07", text: "Payment received — INV-2026-041, thank you.", who: "System" },
    { dot: "#B85F3D", date: "2026-05-04", text: "Clara left notes on milestone 2.", who: "Clara Mendoza" },
    { dot: "#2E8169", date: "2026-04-28", text: "Recap of the follow-up meeting is ready.", who: "Clara Mendoza" },
  ];
  return (
    <div>
      {items.map((it, i) => (
        <div key={i} style={{
          display: "grid", gridTemplateColumns: "10px 1fr 100px",
          gap: 16, padding: "12px 0", borderBottom: "1px solid rgba(31,42,38,0.10)", alignItems: "center",
        }}>
          <span style={{ width: 6, height: 6, borderRadius: 999, background: it.dot, marginLeft: 2 }}/>
          <div>
            <div style={{ fontFamily: "Newsreader, serif", fontSize: 15, color: "#1F2A26", lineHeight: 1.4 }}>{it.text}</div>
            <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)", marginTop: 3 }}>{it.who}</div>
          </div>
          <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.5)", textAlign: "right" }}>{fmtDateShortC(it.date, lang)}</span>
        </div>
      ))}
    </div>
  );
}

/* ================================================================
   PORTAL: ALL SERVICES
   ================================================================ */
function PortalServicesPage() {
  const t = useT();
  const { lang } = useApp();
  const c = getPortalClient();
  const services = c.services.map(serviceOfC).filter(Boolean);

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "tus servicios" : "your services"}
        title={lang === "es"
          ? `Lo que estamos construyendo <em style="font-style:italic;font-weight:300;color:#2E8169">contigo</em>`
          : `What we're building <em style="font-style:italic;font-weight:300;color:#2E8169">with you</em>`}
        lede={lang === "es"
          ? "Cada servicio mantiene su propio progreso, hitos y equipo. Puedes pausar el mantenimiento cuando quieras."
          : "Each service has its own progress, milestones and team. You can pause maintenance whenever you want."}
      />
      <Toolbar>
        <FilterChip active>{t("common.all")}</FilterChip>
        <FilterChip>{t("svc.assessment")}</FilterChip>
        <FilterChip>{t("svc.development")}</FilterChip>
        <FilterChip>{t("svc.formation")}</FilterChip>
      </Toolbar>
      <div style={{ padding: "0 40px" }}>
        {services.map(s => <PortalServiceCard key={s.id} service={s}/>)}
      </div>
    </>
  );
}

/* ================================================================
   PORTAL: DIAGNOSTIC DETAIL (deliverable view)
   ================================================================ */
function PortalDiagnosticPage() {
  const t = useT();
  const { lang } = useApp();
  const c = getPortalClient();
  const s = c.services.map(serviceOfC).find(x => x && x.type === "assessment");
  if (!s) return <div style={{ padding: 40 }}>—</div>;

  return (
    <>
      {/* Breadcrumb */}
      <div style={{ padding: "20px 40px 12px", fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(31,42,38,0.55)" }}>
        <a href="#/portal" style={{ color: "rgba(31,42,38,0.55)" }}>{lang === "es" ? "Inicio" : "Home"}</a>
        <span style={{ margin: "0 8px" }}>/</span>
        <span style={{ color: "#1F2A26" }}>{lang === "es" ? "Diagnóstico" : "Diagnostic"}</span>
      </div>

      <header style={{ padding: "0 40px 32px", borderBottom: "1px solid rgba(31,42,38,0.14)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
          <ServiceTypeBadge type="assessment"/>
          <StatusPill status="completed"/>
        </div>
        <h1 style={{
          fontFamily: "Newsreader, serif", fontWeight: 400, fontSize: 56,
          letterSpacing: "-0.02em", lineHeight: 1.05, color: "#1F2A26",
          margin: "0 0 14px", maxWidth: 900,
        }}>
          {lang === "es" ? <><em style={{ fontStyle: "italic", color: "#2E8169", fontWeight: 300 }}>AI Readiness</em> · diagnóstico de Naviera Mediterránea</> :
                          <><em style={{ fontStyle: "italic", color: "#2E8169", fontWeight: 300 }}>AI Readiness</em> · Naviera Mediterránea diagnostic</>}
        </h1>
        <p style={{ fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 19, color: "rgba(31,42,38,0.6)", maxWidth: 720, lineHeight: 1.5, margin: 0 }}>
          {lang === "es"
            ? "Tres semanas de conversación. Catorce procesos auditados. Un mapa priorizado de dónde tiene sentido la IA — y dónde no — en la naviera."
            : "Three weeks of conversation. Fourteen processes audited. A prioritised map of where AI makes sense — and where it doesn't — for the shipping line."}
        </p>
      </header>

      {/* Score + summary */}
      <Section title={lang === "es" ? `Tu <em style="font-style:italic;color:#2E8169;font-weight:400">score</em>` : `Your <em style="font-style:italic;color:#2E8169;font-weight:400">score</em>`}>
        <ScoreBlock score={s.score}/>
      </Section>

      <Section title={lang === "es" ? "Resumen ejecutivo" : "Executive summary"} padded={true}
        margin={lang === "es" ? "Versión completa: 42 páginas. Esto es lo justo para una primera lectura." : "Full version: 42 pages. This is the read-it-now version."}
      >
        <div style={{ fontFamily: "Newsreader, serif", fontSize: 18, lineHeight: 1.6, color: "#3B463F", maxWidth: 760 }}>
          {lang === "es" ? (
            <>
              <p style={{ margin: "0 0 16px" }}>
                Naviera Mediterránea es una empresa <i style={{color:"#1F5B49"}}>técnicamente sólida</i> con un alto nivel de cumplimiento normativo, pero con un déficit importante en infraestructura de datos: el ERP convive con cuatro hojas de cálculo críticas para operaciones diarias.
              </p>
              <p style={{ margin: "0 0 16px" }}>
                Las dos áreas con mayor retorno potencial son <i style={{color:"#1F5B49"}}>la generación automática de manifiestos aduaneros</i> y <i style={{color:"#1F5B49"}}>la previsión de mantenimiento de flota</i> usando datos del SAP y de los sensores embarcados.
              </p>
              <p style={{ margin: 0 }}>
                Recomendamos <i style={{color:"#1F5B49"}}>no abordar</i>, por ahora, la asistencia conversacional al cliente final. El volumen no justifica la inversión y los datos de contexto están demasiado dispersos.
              </p>
            </>
          ) : (
            <>
              <p style={{ margin: "0 0 16px" }}>
                Naviera Mediterránea is a <i style={{color:"#1F5B49"}}>technically solid</i> company with strong regulatory compliance, but a serious data-infrastructure gap: the ERP coexists with four spreadsheets that are critical to daily operations.
              </p>
              <p style={{ margin: "0 0 16px" }}>
                The two areas with the highest potential return are <i style={{color:"#1F5B49"}}>automated customs manifest generation</i> and <i style={{color:"#1F5B49"}}>fleet predictive maintenance</i> using SAP data and onboard sensor feeds.
              </p>
              <p style={{ margin: 0 }}>
                We recommend <i style={{color:"#1F5B49"}}>not pursuing</i>, for now, conversational customer assistance. Volume doesn't justify the investment and context data is too fragmented.
              </p>
            </>
          )}
        </div>
      </Section>

      {/* Prioritised plan */}
      <Section title={lang === "es" ? "Plan priorizado" : "Prioritised plan"}
        margin={lang === "es" ? "Tres ítems verdes, cuatro amarillos, dos en rojo. El verde se puede empezar ya." : "Three green, four yellow, two red. Green can start now."}
      >
        <div style={{ display: "grid", gridTemplateColumns: "100px 1fr 140px 140px", gap: 0, borderTop: "1px solid rgba(31,42,38,0.14)" }}>
          {[
            { n: "01", txt: lang === "es" ? "Manifiestos aduaneros automáticos" : "Automated customs manifests", impact: "alto", effort: "medio", priority: "go" },
            { n: "02", txt: lang === "es" ? "Mantenimiento predictivo de flota" : "Fleet predictive maintenance", impact: "alto", effort: "alto", priority: "go" },
            { n: "03", txt: lang === "es" ? "Asistente interno sobre contratos" : "Internal contracts assistant", impact: "medio", effort: "bajo", priority: "go" },
            { n: "04", txt: lang === "es" ? "Análisis de incidencias de carga" : "Cargo incident analysis", impact: "medio", effort: "medio", priority: "wait" },
            { n: "05", txt: lang === "es" ? "Previsión de demanda por ruta" : "Per-route demand forecasting", impact: "medio", effort: "alto", priority: "wait" },
            { n: "06", txt: lang === "es" ? "Optimización dinámica de precios" : "Dynamic pricing optimisation", impact: "alto", effort: "alto", priority: "wait" },
            { n: "07", txt: lang === "es" ? "Asistente cliente final por chat" : "Customer-facing chat assistant", impact: "bajo", effort: "alto", priority: "no" },
          ].map((it, i) => (
            <React.Fragment key={i}>
              <div style={{ padding: "20px 0", borderBottom: "1px solid rgba(31,42,38,0.10)", paddingLeft: 0,
                fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 28,
                fontWeight: 300, color: it.priority === "go" ? "#2E8169" : it.priority === "wait" ? "#B85F3D" : "rgba(31,42,38,0.3)" }}>
                {it.n}
              </div>
              <div style={{ padding: "20px 0", borderBottom: "1px solid rgba(31,42,38,0.10)",
                fontFamily: "Newsreader, serif", fontSize: 17, color: "#1F2A26" }}>{it.txt}</div>
              <div style={{ padding: "20px 0", borderBottom: "1px solid rgba(31,42,38,0.10)",
                fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(31,42,38,0.6)" }}>
                <span style={{ fontFamily: "Inter, sans-serif", fontSize: 10, letterSpacing: "0.18em", textTransform: "uppercase", color: "rgba(31,42,38,0.5)" }}>{lang === "es" ? "Impacto" : "Impact"}: </span>{it.impact}
                <br/><span style={{ fontFamily: "Inter, sans-serif", fontSize: 10, letterSpacing: "0.18em", textTransform: "uppercase", color: "rgba(31,42,38,0.5)" }}>{lang === "es" ? "Esfuerzo" : "Effort"}: </span>{it.effort}
              </div>
              <div style={{ padding: "20px 0", borderBottom: "1px solid rgba(31,42,38,0.10)" }}>
                <span style={{
                  display: "inline-block", padding: "3px 10px",
                  fontFamily: "Inter, sans-serif", fontSize: 11, letterSpacing: "0.04em",
                  border: "1px solid",
                  borderColor: it.priority === "go" ? "#2E8169" : it.priority === "wait" ? "#B85F3D" : "rgba(31,42,38,0.3)",
                  color:       it.priority === "go" ? "#2E8169" : it.priority === "wait" ? "#B85F3D" : "rgba(31,42,38,0.5)",
                  borderRadius: 1, textTransform: "uppercase",
                }}>{it.priority === "go" ? (lang === "es" ? "Hacer ya" : "Do now") : it.priority === "wait" ? (lang === "es" ? "Esperar" : "Wait") : (lang === "es" ? "No hacer" : "Skip")}</span>
              </div>
            </React.Fragment>
          ))}
        </div>
      </Section>

      {/* CTA next step */}
      <div style={{
        margin: "0 40px 56px", marginTop: 40,
        background: "#14201B", color: "#F4F1EA", padding: "48px 56px",
        borderRadius: 2, position: "relative", overflow: "hidden",
      }}>
        <div style={{
          fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 14,
          color: "#6BBF96", marginBottom: 10,
        }}>— {lang === "es" ? "siguiente paso" : "next step"}</div>
        <h2 style={{
          fontFamily: "Newsreader, serif", fontWeight: 400, fontSize: 36,
          letterSpacing: "-0.02em", color: "#F4F1EA", lineHeight: 1.15, margin: "0 0 14px", maxWidth: 600,
        }}>
          {lang === "es"
            ? <>¿Empezamos con <em style={{ fontStyle: "italic", color: "#6BBF96", fontWeight: 300 }}>manifiestos automáticos</em>?</>
            : <>Shall we start with <em style={{ fontStyle: "italic", color: "#6BBF96", fontWeight: 300 }}>automated manifests</em>?</>}
        </h2>
        <p style={{ fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 17, color: "rgba(244,241,234,0.7)", maxWidth: 560, lineHeight: 1.5, margin: "0 0 24px" }}>
          {lang === "es"
            ? "Te preparamos propuesta con coste de desarrollo, tiempo y modelo de mantenimiento. Sin compromiso."
            : "We'll prepare a proposal with build cost, timeline and maintenance model. No commitment."}
        </p>
        <div style={{ display: "flex", gap: 12 }}>
          <button style={{
            padding: "10px 20px", background: "transparent", color: "#F4F1EA",
            border: "1px solid rgba(244,241,234,0.3)", borderRadius: 4,
            fontFamily: "Inter, sans-serif", fontSize: 13, letterSpacing: "0.02em", cursor: "pointer",
          }}>{lang === "es" ? "Pedir propuesta →" : "Request proposal →"}</button>
          <button style={{
            padding: "10px 20px", background: "transparent", color: "rgba(244,241,234,0.6)",
            border: "none", borderRadius: 4, fontFamily: "Newsreader, serif", fontStyle: "italic",
            fontSize: 15, cursor: "pointer",
          }}>{lang === "es" ? "¿Una conversación primero?" : "A conversation first?"}</button>
        </div>
      </div>
    </>
  );
}

/* ================================================================
   PORTAL: INVOICES
   ================================================================ */
function PortalInvoicesPage() {
  const t = useT();
  const { lang } = useApp();
  const c = getPortalClient();
  const rows = DC.invoices.filter(i => i.clientId === c.id && i.issued)
    .sort((a,b) => (b.issued || "").localeCompare(a.issued || ""));

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "facturas" : "invoices"}
        title={lang === "es"
          ? `Todo lo que ha pasado por <em style="font-style:italic;font-weight:300;color:#2E8169">caja</em>`
          : `Everything that's gone through <em style="font-style:italic;font-weight:300;color:#2E8169">accounts</em>`}
        lede={lang === "es"
          ? "Facturas únicas, mantenimiento mensual y pagos. Cada PDF descargable, cada estado visible."
          : "One-time fees, monthly maintenance, payments. Every PDF downloadable, every status visible."}
        right={<Btn kind="ghost" size="sm" icon="stripe">{lang === "es" ? "Pagar con Stripe" : "Pay with Stripe"}</Btn>}
      />
      <Table
        columns={[
          { key: "id",     label: "ID",                            w: "130px", render: r => <span style={{ fontFamily: "Inter, sans-serif", fontVariantNumeric: "tabular-nums" }}>{r.id}</span>},
          { key: "concept", label: lang === "es" ? "Concepto" : "Concept", w: "1.6fr",
            render: r => (
              <div>
                <div>{r.concept}</div>
                {r.recurring && <div style={{ fontSize: 11, color: "#2E8169", fontStyle: "italic", fontFamily: "Newsreader, serif", marginTop: 2 }}>{lang === "es" ? "recurrente mensual" : "monthly recurring"}</div>}
              </div>
            )},
          { key: "issued", label: lang === "es" ? "Emitida" : "Issued", w: "110px", render: r => <span style={{ color: "rgba(31,42,38,0.6)" }}>{fmtDateShortC(r.issued, lang)}</span>},
          { key: "due",    label: lang === "es" ? "Vencimiento" : "Due", w: "110px", render: r => <span style={{ color: r.status === "overdue" ? "#cc3c28" : "rgba(31,42,38,0.6)" }}>{fmtDateShortC(r.due, lang)}</span>},
          { key: "method", label: lang === "es" ? "Método" : "Method", w: "120px", render: r => r.method ? (
            <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "rgba(31,42,38,0.7)" }}>
              <Icon name={r.method === "stripe" ? "stripe" : "billing"} size={13}/>
              {r.method === "stripe" ? "Stripe" : (lang === "es" ? "Transferencia" : "Transfer")}
            </span>
          ) : "—"},
          { key: "amount", label: t("common.value"),               w: "110px", align: "right", render: r => <span style={{ fontVariantNumeric: "tabular-nums", fontWeight: 500 }}>{fmtMoneyC(r.amount, lang)}</span>},
          { key: "status", label: "",                              w: "100px", render: r => <StatusPill status={r.status}/>},
          { key: "pdf",    label: "",                              w: "30px",  render: r => <a href="#" style={{ color: "rgba(31,42,38,0.5)" }} title="PDF"><Icon name="doc" size={14}/></a>},
        ]}
        rows={rows}
      />
    </>
  );
}

/* ================================================================
   PORTAL: DOCUMENTS
   ================================================================ */
function PortalDocumentsPage() {
  const t = useT();
  const { lang } = useApp();
  const c = getPortalClient();
  const docs = DC.documents.filter(d => d.clientId === c.id);

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "documentos compartidos" : "shared documents"}
        title={lang === "es"
          ? `Todo lo que hemos <em style="font-style:italic;font-weight:300;color:#2E8169">producido</em> juntos`
          : `Everything we've <em style="font-style:italic;font-weight:300;color:#2E8169">made</em> together`}
        lede={lang === "es"
          ? "Entregables, contratos, sesiones grabadas y materiales de formación. Sincronizados con tu Drive."
          : "Deliverables, contracts, recordings, training materials. Synced with your Drive."}
        right={
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Icon name="google" size={16}/>
            <span style={{ fontFamily: "Inter, sans-serif", fontSize: 11.5, color: "rgba(31,42,38,0.55)" }}>{lang === "es" ? "Sincronizado con Drive" : "Drive synced"}</span>
          </div>
        }
      />
      <Toolbar>
        <FilterChip active>{t("common.all")}</FilterChip>
        <FilterChip>PDF</FilterChip>
        <FilterChip>DOCX</FilterChip>
        <FilterChip>{lang === "es" ? "Vídeos" : "Videos"}</FilterChip>
      </Toolbar>
      <Table
        columns={[
          { key: "name", label: lang === "es" ? "Nombre" : "Name", w: "1.8fr",
            render: r => (
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{
                  width: 32, height: 36, background: "#F4F1EA",
                  border: "1px solid rgba(31,42,38,0.18)", borderRadius: 1,
                  display: "inline-flex", alignItems: "center", justifyContent: "center",
                  fontFamily: "Inter, sans-serif", fontSize: 9, color: "rgba(31,42,38,0.55)",
                  letterSpacing: "0.04em",
                }}>{(r.kind || "").toUpperCase()}</div>
                <div>
                  <div style={{ fontWeight: 500, color: "#1F2A26" }}>{r.name}</div>
                  <div style={{ fontSize: 11, color: "rgba(31,42,38,0.55)", marginTop: 2 }}>
                    {r.size} · {lang === "es" ? "actualizado " : "updated "}{fmtDateShortC(r.updated, lang)}
                  </div>
                </div>
              </div>
            )},
          { key: "linked", label: lang === "es" ? "Vinculado a" : "Linked to", w: "1fr",
            render: r => r.serviceId ? <span style={{ color: "rgba(31,42,38,0.7)" }}>{serviceOfC(r.serviceId).title}</span> : <span style={{ color: "rgba(31,42,38,0.4)", fontStyle: "italic", fontFamily: "Newsreader, serif" }}>—</span>},
          { key: "shared", label: lang === "es" ? "Compartido por" : "Shared by", w: "180px",
            render: r => <Avatar user={userOfC(r.uploadedBy)} size={22} label/>},
          { key: "action", label: "", w: "100px", render: () => (
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
              <a href="#" style={{ color: "rgba(31,42,38,0.55)" }} title="Open"><Icon name="ext" size={14}/></a>
              <a href="#" style={{ color: "rgba(31,42,38,0.55)" }} title="Download"><Icon name="doc" size={14}/></a>
            </div>
          )},
        ]}
        rows={docs}
      />
    </>
  );
}

/* ================================================================
   PORTAL: MESSAGES (chat)
   ================================================================ */
function PortalMessagesPage() {
  const { lang } = useApp();
  const t = useT();
  const c = getPortalClient();
  const owner = userOfC(c.owner);
  const me = c.contacts[0];

  const messages = lang === "es" ? [
    { from: "team", who: owner, time: "ayer · 14:32", text: "Hola Pablo, te dejé el documento técnico v0.3 en la carpeta del proyecto. Estoy disponible mañana si quieres comentarlo." },
    { from: "you",  who: { name: me.name, avatar: "PB", color: "#B85F3D" }, time: "ayer · 17:08", text: "Perfecto, lo reviso esta tarde. ¿Tenemos confirmado el tema de la auditoría de seguridad?" },
    { from: "team", who: owner, time: "ayer · 17:12", text: "Sí — Pepe revisó el alcance esta mañana. Te paso el plan en cuanto lo cierre. Va dentro del precio acordado." },
    { from: "team", who: userOfC("u-diego"), time: "hoy · 09:14", text: "Por mi parte: he subido el endpoint nuevo al staging. Te paso las credenciales por separado." },
    { from: "you",  who: { name: me.name, avatar: "PB", color: "#B85F3D" }, time: "hoy · 09:48", text: "Gracias Diego. Probamos esta tarde con el equipo de operaciones y os digo." },
  ] : [
    { from: "team", who: owner, time: "yesterday · 14:32", text: "Hi Pablo — I left technical doc v0.3 in the project folder. Available tomorrow if you want to walk through it." },
    { from: "you",  who: { name: me.name, avatar: "PB", color: "#B85F3D" }, time: "yesterday · 17:08", text: "Great, I'll review this evening. Did we lock in the security audit scope?" },
    { from: "team", who: owner, time: "yesterday · 17:12", text: "Yes — Pepe signed off this morning. Plan coming once it's finalized. Stays inside the agreed price." },
    { from: "team", who: userOfC("u-diego"), time: "today · 09:14", text: "On my end: the new endpoint is on staging. Sending credentials separately." },
    { from: "you",  who: { name: me.name, avatar: "PB", color: "#B85F3D" }, time: "today · 09:48", text: "Thanks Diego. We'll test with operations this afternoon and report back." },
  ];

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "conversación" : "conversation"}
        title={lang === "es"
          ? `Hablar con tu <em style="font-style:italic;font-weight:300;color:#2E8169">equipo</em>`
          : `Talk to your <em style="font-style:italic;font-weight:300;color:#2E8169">team</em>`}
        lede={lang === "es"
          ? "Una conversación abierta. Pepe, Clara y Diego ven los mensajes y se reparten quién responde."
          : "One open thread. Pepe, Clara and Diego all see messages and decide who replies."}
      />
      <div style={{
        margin: "0 40px 40px", border: "1px solid rgba(31,42,38,0.14)",
        background: "#F4F1EA", borderRadius: 2,
      }}>
        {/* Header */}
        <div style={{
          padding: "16px 24px", borderBottom: "1px solid rgba(31,42,38,0.10)",
          display: "flex", justifyContent: "space-between", alignItems: "center",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <AvatarStack users={[owner, userOfC("u-diego"), userOfC("u-pepe")]} size={26}/>
            <div>
              <div style={{ fontFamily: "Newsreader, serif", fontSize: 15, color: "#1F2A26" }}>{lang === "es" ? "Equipo Zanovix · Naviera Mediterránea" : "Zanovix team · Naviera Mediterránea"}</div>
              <div style={{ fontFamily: "Inter, sans-serif", fontSize: 11, color: "rgba(31,42,38,0.55)", marginTop: 2 }}>{lang === "es" ? "3 personas · normalmente responden en < 4h" : "3 people · usually reply in < 4h"}</div>
            </div>
          </div>
          <Btn kind="quiet" size="sm" icon="calendar">{lang === "es" ? "Agendar reunión" : "Schedule meeting"}</Btn>
        </div>

        {/* Messages */}
        <div style={{ padding: "24px 32px", display: "flex", flexDirection: "column", gap: 22, minHeight: 480 }}>
          {messages.map((m, i) => (
            <div key={i} style={{
              display: "flex", flexDirection: m.from === "you" ? "row-reverse" : "row",
              gap: 12, alignItems: "flex-end",
            }}>
              <Avatar user={m.who} size={28}/>
              <div style={{ maxWidth: "60%" }}>
                <div style={{
                  fontFamily: "Inter, sans-serif", fontSize: 10.5,
                  color: "rgba(31,42,38,0.55)", marginBottom: 4,
                  textAlign: m.from === "you" ? "right" : "left",
                  letterSpacing: "0.02em",
                }}>{m.who.name} · {m.time}</div>
                <div style={{
                  padding: "12px 16px",
                  background: m.from === "you" ? "#1F2A26" : "#ECE6D6",
                  color: m.from === "you" ? "#F4F1EA" : "#1F2A26",
                  borderRadius: 2, fontFamily: "Newsreader, serif", fontSize: 16,
                  lineHeight: 1.5,
                }}>{m.text}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Composer */}
        <div style={{ borderTop: "1px solid rgba(31,42,38,0.10)", padding: "14px 20px", display: "flex", gap: 12, alignItems: "center" }}>
          <input type="text" placeholder={lang === "es" ? "Escribe un mensaje a tu equipo…" : "Write a message to your team…"}
            style={{
              flex: 1, padding: "10px 12px", border: "1px solid rgba(31,42,38,0.18)",
              borderRadius: 2, background: "#F4F1EA",
              fontFamily: "Newsreader, serif", fontSize: 15, color: "#1F2A26", outline: "none",
            }}/>
          <Btn kind="ghost" size="sm" icon="doc">{lang === "es" ? "Adjuntar" : "Attach"}</Btn>
          <Btn kind="accent" size="sm">{lang === "es" ? "Enviar" : "Send"}</Btn>
        </div>
      </div>
    </>
  );
}

/* ================================================================
   PORTAL: SUPPORT
   ================================================================ */
function PortalSupportPage() {
  const { lang } = useApp();
  const t = useT();
  const tickets = lang === "es" ? [
    { id: "TCK-014", title: "Endpoint de manifiestos devuelve 502 desde el lunes", service: "Manifiestos automáticos", priority: "alta", status: "in_progress", updated: "2026-05-11" },
    { id: "TCK-013", title: "Mejora: añadir filtro por flota al dashboard", service: "Manifiestos automáticos", priority: "media", status: "pending", updated: "2026-05-09" },
    { id: "TCK-011", title: "Pregunta: ¿cómo regeneramos las claves API?", service: "Manifiestos automáticos", priority: "baja", status: "closed", updated: "2026-05-04" },
    { id: "TCK-008", title: "Documentación de la sesión 1 de formación", service: "Formación AI Act", priority: "baja", status: "closed", updated: "2026-04-29" },
  ] : [
    { id: "TCK-014", title: "Manifest endpoint returning 502 since Monday", service: "Automated manifests", priority: "high", status: "in_progress", updated: "2026-05-11" },
    { id: "TCK-013", title: "Improvement: filter dashboard by fleet", service: "Automated manifests", priority: "medium", status: "pending", updated: "2026-05-09" },
    { id: "TCK-011", title: "Question: how do we rotate API keys?", service: "Automated manifests", priority: "low", status: "closed", updated: "2026-05-04" },
    { id: "TCK-008", title: "Training session 1 documentation", service: "AI Act training", priority: "low", status: "closed", updated: "2026-04-29" },
  ];

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "soporte y mantenimiento" : "support & maintenance"}
        title={lang === "es"
          ? `Cosas que necesitan <em style="font-style:italic;font-weight:300;color:#2E8169">mano</em>`
          : `Things that need a <em style="font-style:italic;font-weight:300;color:#2E8169">hand</em>`}
        lede={lang === "es"
          ? "Incidencias, mejoras y preguntas sobre las soluciones que mantenemos. Respondemos en menos de 24h hábiles."
          : "Incidents, improvements and questions on the systems we maintain. We respond in under 24 working hours."}
        right={<Btn kind="accent" size="sm" icon="plus">{lang === "es" ? "Abrir ticket" : "Open ticket"}</Btn>}
      />
      <Toolbar>
        <FilterChip active>{t("common.all")} · {tickets.length}</FilterChip>
        <FilterChip>{lang === "es" ? "Abiertos" : "Open"}</FilterChip>
        <FilterChip>{lang === "es" ? "En curso" : "In progress"}</FilterChip>
        <FilterChip>{lang === "es" ? "Cerrados" : "Closed"}</FilterChip>
      </Toolbar>
      <Table
        columns={[
          { key: "id", label: "ID", w: "110px", render: r => <span style={{ fontFamily: "Inter, sans-serif", fontVariantNumeric: "tabular-nums" }}>{r.id}</span>},
          { key: "title", label: lang === "es" ? "Asunto" : "Subject", w: "1.8fr",
            render: r => <span style={{ color: "#1F2A26", fontWeight: 500 }}>{r.title}</span>},
          { key: "service", label: lang === "es" ? "Servicio" : "Service", w: "1fr", render: r => <span style={{ color: "rgba(31,42,38,0.7)" }}>{r.service}</span>},
          { key: "priority", label: lang === "es" ? "Prioridad" : "Priority", w: "110px",
            render: r => {
              const c = r.priority === "alta" || r.priority === "high" ? "#cc3c28" : (r.priority === "media" || r.priority === "medium") ? "#B85F3D" : "rgba(31,42,38,0.6)";
              return <span style={{ display: "inline-flex", alignItems: "center", gap: 5, color: c, fontFamily: "Inter, sans-serif", fontSize: 12, textTransform: "capitalize" }}>
                <span style={{ width: 6, height: 6, borderRadius: 999, background: c }}/>{r.priority}
              </span>;
            }},
          { key: "status", label: "", w: "120px", render: r => <StatusPill status={r.status}/>},
          { key: "updated", label: lang === "es" ? "Actualizado" : "Updated", w: "110px", render: r => <span style={{ color: "rgba(31,42,38,0.55)" }}>{fmtDateShortC(r.updated, lang)}</span>},
        ]}
        rows={tickets}
      />
    </>
  );
}

/* ================================================================
   PORTAL: CALENDAR (light view)
   ================================================================ */
function PortalCalendarPage() {
  const { lang } = useApp();
  const t = useT();
  const c = getPortalClient();
  const events = DC.events.filter(e => e.clientId === c.id).sort((a,b) => (a.date+a.time).localeCompare(b.date+b.time));

  return (
    <>
      <PageHeader
        eyebrow={lang === "es" ? "agenda" : "agenda"}
        title={lang === "es"
          ? `Cuándo nos <em style="font-style:italic;font-weight:300;color:#2E8169">vemos</em>`
          : `When we <em style="font-style:italic;font-weight:300;color:#2E8169">meet</em>`}
        lede={lang === "es"
          ? "Reuniones programadas con el equipo Zanovix. Puedes proponer nueva fecha o anular cualquiera con 24h."
          : "Scheduled meetings with the Zanovix team. Propose a new date or cancel any with 24h notice."}
        right={<Btn kind="accent" size="sm" icon="plus">{lang === "es" ? "Proponer reunión" : "Propose meeting"}</Btn>}
      />
      <div style={{ padding: "0 40px 40px" }}>
        {events.length === 0 && <div style={{ padding: "40px 0", fontFamily: "Newsreader, serif", fontStyle: "italic", color: "rgba(31,42,38,0.5)" }}>—</div>}
        {events.map((ev, i) => {
          const isPast = ev.date < "2026-05-11";
          return (
            <div key={ev.id} style={{
              display: "grid", gridTemplateColumns: "100px 1fr 200px 120px",
              gap: 24, padding: "22px 0", alignItems: "center",
              borderBottom: i === events.length - 1 ? "1px solid rgba(31,42,38,0.14)" : "1px solid rgba(31,42,38,0.10)",
              borderTop: i === 0 ? "1px solid rgba(31,42,38,0.14)" : "none",
              opacity: isPast ? 0.55 : 1,
            }}>
              <div>
                <div style={{ fontFamily: "Newsreader, serif", fontStyle: "italic", fontSize: 13, color: "rgba(31,42,38,0.55)" }}>{fmtDateShortC(ev.date, lang)}</div>
                <div style={{ fontFamily: "Newsreader, serif", fontSize: 28, fontWeight: 400, color: "#1F2A26", letterSpacing: "-0.01em", lineHeight: 1.05 }}>{ev.time}</div>
              </div>
              <div>
                <div style={{ fontFamily: "Newsreader, serif", fontSize: 18, color: "#1F2A26", lineHeight: 1.3 }}>{ev.title}</div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(31,42,38,0.55)", marginTop: 4 }}>{ev.duration}min · {lang === "es" ? "Google Meet" : "Google Meet"}</div>
              </div>
              <div>
                <div style={{ fontFamily: "Inter, sans-serif", fontSize: 10.5, letterSpacing: "0.18em", textTransform: "uppercase", color: "rgba(31,42,38,0.55)", marginBottom: 6 }}>{lang === "es" ? "Asistentes" : "Attendees"}</div>
                <AvatarStack users={ev.attendees.map(userOfC)} size={22}/>
              </div>
              <div style={{ textAlign: "right" }}>
                {!isPast ? (
                  <a href="#" style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "#2E8169", borderBottom: "1px solid #2E8169" }}>{lang === "es" ? "Unirse" : "Join"} →</a>
                ) : (
                  <a href="#" style={{ fontFamily: "Inter, sans-serif", fontSize: 12, color: "rgba(31,42,38,0.5)", borderBottom: "1px solid rgba(31,42,38,0.3)" }}>{lang === "es" ? "Resumen" : "Recap"} →</a>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}

Object.assign(window, {
  PortalDashboardPage, PortalServicesPage, PortalDiagnosticPage,
  PortalInvoicesPage, PortalDocumentsPage, PortalMessagesPage,
  PortalSupportPage, PortalCalendarPage,
});
