# Handoff: Zanovix CRM

## Overview

Prototipo navegable hi-fi de un CRM bilingüe (ES/EN) para **Zanovix**, una consultoría de IA. El sistema tiene dos lados que comparten datos pero presentan información distinta:

1. **Lado interno** (`/admin/*`) — para Pepe (fundador/admin), Clara (consultora), Diego (desarrollador). Gestiona el flujo completo de un cliente: lead → discovery → propuesta → cliente activo → servicios en curso → mantenimiento.
2. **Portal cliente** (`/client/*` o `/portal/*`) — el cliente ve sólo lo suyo: servicios contratados, progreso, hitos, facturas, documentos compartidos y un chat con el equipo.

El switch entre vistas está en el topbar, igual que el toggle ES/EN y el selector de rol.

## About the Design Files

Los archivos de este bundle son **referencias de diseño construidas en HTML + React (via Babel inline)** — un prototipo que muestra el look & feel deseado, las interacciones y la estructura de datos. **No son código de producción para copiar tal cual.**

La tarea es **recrear estos diseños en el stack real del codebase de Zanovix** usando sus patrones establecidos (componentes, librerías, sistema de routing, ORM, etc.). Si todavía no existe codebase, la recomendación es:

- **Front-end:** Next.js 15 (App Router) + React 18 + TypeScript + Tailwind CSS + shadcn/ui. El prototipo ya está pensado en React y la traducción a Next es directa.
- **Back-end / BBDD:** PostgreSQL (Supabase o Neon) + Prisma + tRPC o Server Actions.
- **Auth:** Supabase Auth o Clerk (multi-tenant con dos roles base: `internal_*` y `client_*`).
- **Pagos:** Stripe Billing (suscripciones para mantenimiento mensual + pagos únicos para setup/desarrollo).
- **Calendario:** Google Calendar API (OAuth, sincronización bidireccional).
- **Almacenamiento:** Google Drive API o Supabase Storage para documentos compartidos.
- **i18n:** `next-intl` (el prototipo ya tiene los strings ES/EN extraídos en `src/i18n.jsx`).

## Fidelity

**Hi-fi.** Los colores, tipografía, espaciado y micro-interacciones son finales y reflejan la marca Zanovix (estética editorial, papel crudo, verde botánico, tipografía serif Newsreader + Inter). Recrear pixel-perfect respetando el sistema de design tokens (sección **Design Tokens** abajo).

## Architecture & Routes

### Lado interno (`/admin/*`)

| Ruta | Vista | Propósito |
|---|---|---|
| `/admin` | **Dashboard** | KPIs (MRR, pipeline value, deals en marcha, próximos cobros), embudo del pipeline, agenda del día, actividad reciente. |
| `/admin/pipeline` | **Pipeline** | Kanban con 5 etapas: Lead → Discovery agendada → Discovery realizada → Propuesta enviada → Activo. También vista lista con filtros por owner, sector, tamaño. |
| `/admin/clients` | **Clientes** | Tabla maestra de cuentas con etapa, owner, MRR, próximo hito, contactos. |
| `/admin/clients/:id` | **Cliente 360** | Detalle por cliente: contactos, servicios activos, facturación, actividad cronológica, documentos, equipo asignado. |
| `/admin/services/:id` | **Servicio detalle** | Hitos del servicio (assessment / development / formation), score si es diagnóstico, facturación vinculada, stack/integraciones, visibilidad para cliente. |
| `/admin/billing` | **Facturación** | Tabla de facturas con filtros (pagadas / pendientes / vencidas / borrador) + KPIs (recurrente mensual, cobrado YTD, pendiente). |
| `/admin/calendar` | **Calendario** | Vista semanal sincronizada con Google Calendar. Eventos coloreados por tipo (discovery, assessment, review, formation, proposal, demo, internal). |
| `/admin/team` | **Equipo** | Miembros con rol, clientes asignados, servicios activos, % de carga. |

### Portal cliente (`/client/*`)

| Ruta | Vista | Propósito |
|---|---|---|
| `/client` | **Dashboard** | Saludo personal, KPIs (servicios activos, próxima reunión, pendiente de pago, docs nuevos), cards de servicios con progreso, actividad reciente, panel lateral con equipo + reuniones + documentos. |
| `/client/diagnostic` | **Diagnóstico** | Entregable del AI Readiness Assessment: score visual sobre 100 con 6 dimensiones (datos, procesos, equipo, infraestructura, cumplimiento, liderazgo), resumen ejecutivo, plan priorizado (go / wait / skip), CTA a propuesta. |
| `/client/projects` | **Servicios** | Lista de servicios del cliente con progreso y estado. |
| `/client/services/:id` | **Servicio detalle** | Misma vista que admin pero con permisos de cliente. |
| `/client/billing` | **Facturas** | Tabla de facturas propias con descarga de PDF y botón "Pagar con Stripe". |
| `/client/documents` | **Documentos** | Drive sincronizado: entregables, contratos, grabaciones, materiales formación. Filtros por tipo. |
| `/client/chat` | **Mensajes** | Conversación abierta con el equipo Zanovix. Mensajes propios alineados a la derecha (fondo `#1F2A26`, texto crema), mensajes del equipo a la izquierda (fondo `#ECE6D6`, texto tinta). Composer con adjuntar + enviar. |
| `/client/meetings` | **Reuniones** | Lista cronológica de eventos con asistentes, link a Google Meet, opción de proponer reunión o ver recap. Eventos pasados con `opacity 0.55`. |
| `/client/support` | **Soporte** | Tickets de incidencias / mejoras / preguntas sobre soluciones en mantenimiento. Filtros por estado, prioridad coloreada. |

## Brand & Voice

- **Tono editorial**, no SaaS. Headers usan Newsreader (serif) con cursivas verdes para palabras-eje. Lede en cursiva, color tinta atenuado.
- **Eyebrows** en minúscula, letterspacing `0.18em`, antecedidas por una raya em (`—`).
- **Márgenes** (notas debajo de títulos de sección) en cursiva, gris, primer-persona corporativa ("Tres semanas de conversación", no "Realizamos 3 sesiones").
- **Copy** es directo, humano y específico. No filler. Ejemplos del prototipo: "Lo que estamos construyendo contigo", "Una conversación abierta. Pepe, Clara y Diego ven los mensajes y se reparten quién responde."

## Design Tokens

### Colors

```css
--zx-paper:      #F4F1EA;  /* Fondo principal — papel crudo */
--zx-paper-2:    #ECE6D6;  /* Fondo secundario — papel más cálido */
--zx-ink:        #1F2A26;  /* Texto / tinta principal */
--zx-ink-soft:   #3B463F;  /* Texto secundario */
--zx-ink-mute:   rgba(31,42,38,0.55);  /* Labels, captions */
--zx-rule:       rgba(31,42,38,0.14);  /* Bordes, separadores */
--zx-night:      #14201B;  /* Bloques CTA oscuros */
--zx-green:      #2E8169;  /* Acento primario — verde botánico */
--zx-green-dark: #1F5B49;  /* Hover de acento */
--zx-green-light:#6BBF96;  /* Highlights sobre fondo oscuro */
--zx-terra:      #B85F3D;  /* Acento secundario — terracota (warning, alta prioridad) */
```

**Status colors:**
- Active / paid / completed / go: `#2E8169`
- Pending / warning / wait / development: `#B85F3D`
- Overdue / error / lost: `#cc3c28`
- Neutral / draft / skip: `rgba(31,42,38,0.5)` / `0.3`

**Background pattern**: el body tiene un grano radial sutil:
```css
background-image: radial-gradient(rgba(31,42,38,0.05) 1px, transparent 1px);
background-size: 6px 6px;
```

### Typography

| Familia | Uso |
|---|---|
| **Newsreader** (Google Fonts, `wght 300–600`, italic disponible) | Headers, titulares, ledes, párrafos editoriales, números grandes |
| **Inter** (Google Fonts, `wght 400/500/600/700`) | UI: nav, labels, captions, tablas, KPIs label, eyebrows |

**Escala (px, todos rounded):**

- H1 página: 48–56 / Newsreader 400 / `letter-spacing -0.02em` / `line-height 1.05`
- H1 sección dentro de página: 38 / Newsreader 400 / `letter-spacing -0.02em`
- H2: 28–32 / Newsreader 400
- Lede: 17–19 / Newsreader italic / `color: rgba(31,42,38,0.6)` / `line-height 1.5`
- Body editorial: 15–18 / Newsreader / `line-height 1.5–1.6`
- UI body: 13 / Inter 400
- Label / caption: 11–12 / Inter / `letter-spacing 0.04–0.18em` / mayúsculas para labels de tabla
- Eyebrow: 11 / Inter 600 / `letter-spacing 0.18em` / mayúsculas / verde o tinta atenuado
- Number prominente (KPI value): 32–48 / Newsreader 400 / `letter-spacing -0.02em`
- Number muy prominente (score 88): 96 / Newsreader 300 / verde
- Tabular nums siempre en valores monetarios y fechas (`font-variant-numeric: tabular-nums`).

### Spacing & sizing

- Container: full-width hasta `1440px`, padding lateral `40px`.
- Sidebar: `232px` ancho fijo.
- Section padding vertical: `40–56px`.
- Card padding: `20–24px`.
- Gap entre cards: `0` (separados por `border-bottom` de `--zx-rule`).
- Border radius: el sistema es **casi plano** — `1–3px` en tablas, botones, badges. Avatares circulares (`999px`).

### Components (resumen)

Ver `src/ui.jsx` para implementación detallada. Lista:

- `Icon(name, size)` — set custom inline SVG (dashboard, pipeline, clients, doc, billing, calendar, team, diag, chat, support, plus, filter, ext, check, google, stripe). **Re-implementar como sprite o react-icons mapping en producción.**
- `StatusPill({status})` — outline pill, color según mapping de estado.
- `ServiceTypeBadge({type})` — badge para assessment / development / formation con icono y label bilingüe.
- `Avatar({user, size, label?})` — círculo con iniciales y color de marca del user. Si `user.photo` existe, usar foto.
- `AvatarStack({users, size})` — stack solapado.
- `Btn({kind, size, icon, children})` — kinds: `accent` (verde sólido), `ghost` (outline tinta), `quiet` (link).
- `PageHeader({eyebrow, title, lede, right})` — el header recurrente con título HTML (permite `<em>` con estilos inline).
- `Section({title, children, margin?, right?, padded?})` — sección con título serif y nota lateral en cursiva.
- `Table({columns, rows})` — tabla con grid layout, header letterspacing, hover row sutil.
- `KPI({label, value, delta?, footnote?})` — card de KPI, label arriba, valor enorme serif, footnote italic.
- `Progress({value, color})` — barra horizontal de 5px de alto.
- `Toolbar({children, right})` — barra de filtros encima de tablas.
- `FilterChip({active, count, children, onClick})` — chip outline / sólido si activo.
- `SidePanel({title, children})` — bloque en el aside derecho.

## Interactions & Behavior

- **Routing**: hash router (`#/admin`, `#/client/diagnostic`, etc.). En producción → Next.js App Router con rutas anidadas `/admin/[...]` y `/client/[...]` con middleware que valida rol.
- **Language toggle**: cambia `lang` en el contexto, todos los strings re-renderizan. Persistir en cookie / preferencia de usuario.
- **Perspective switch**: en el prototipo cambia el lado de la app. En producción será **función del rol** del usuario logueado, no un toggle libre. El toggle del prototipo es para demo.
- **Role selector** (sólo internal): cambia el "current user" para mostrar permisos. En producción es invariable (== usuario logueado).
- **Hover en filas de tabla**: `background: rgba(31,42,38,0.03)`.
- **Click en cliente / servicio / factura**: navega al detalle.
- **Kanban**: drag-and-drop entre columnas. Necesario en producción (no implementado en prototipo aún).
- **Chat composer**: enter envía, shift+enter nueva línea. Soporte para adjuntos (drag-drop sobre el composer).
- **Calendar**: click en celda vacía abre modal "nuevo evento". Click en evento abre detalle.
- **Tweaks panel** (prototipo): permite cambiar color de acento. **No incluir en producción** — eliminar.

## State & Data Model

El prototipo usa datos mock en `src/data.jsx`. El modelo de datos sugerido para Postgres:

### Tablas principales

```
users (id, name, email, role: founder|consultant|developer|pm, color, avatar_url)
clients (id, name, sector, size, region, owner_id → users, stage, entered_at, mrr_cents, lifetime_value_cents, next_milestone)
contacts (id, client_id, name, role, email, phone, is_primary)
services (id, client_id, owner_id, type: assessment|development|formation, title, state: scoping|running|review|completed|maintenance|paused, progress_pct, started_at, ended_at, setup_price_cents, monthly_cents, score_int_nullable)
milestones (id, service_id, n, title, due_date, completed_at_nullable)
invoices (id, client_id, service_id_nullable, concept, amount_cents, status: paid|pending|overdue|draft, issued_at, due_at, method: stripe|transfer, recurring_bool, stripe_invoice_id)
events (id, client_id_nullable, title, kind, start_at, duration_min, google_event_id)
event_attendees (event_id, user_id)
documents (id, client_id, service_id_nullable, name, kind, size_bytes, drive_file_id, uploaded_by, updated_at, visible_to_client_bool)
messages (id, client_id, sender_user_id_nullable, sender_contact_id_nullable, body, created_at, attachments_json)
tickets (id, client_id, service_id, title, priority: high|medium|low, status: pending|in_progress|closed, created_at, updated_at)
activity_log (id, client_id, kind, actor_user_id, body, created_at)
```

### Pipeline stages (enum)

`lead → discovery_scheduled → discovery_done → proposal_sent → active | lost`

### Visibility rules (server-enforced)

- Cliente sólo lee/escribe filas con su `client_id`.
- Documentos visibles al cliente sólo si `visible_to_client = true`.
- Servicios siempre visibles al cliente.
- Tickets sólo del propio cliente.
- Mensajes sólo del propio cliente.

## Integraciones

- **Stripe Billing**: suscripciones mensuales para `services.monthly_cents`, charges únicos para setup / desarrollo. Webhook → actualiza `invoices.status = paid` y posiblea actividad.
- **Google Calendar**: OAuth por usuario interno + por cliente (opcional). Sincronización bidireccional. Filtro por `kind` definido en el evento.
- **Google Drive**: carpeta raíz por cliente. Sync de metadatos a tabla `documents` cada N min.
- **Slack** (opcional fase 2): notificaciones de tickets nuevos al canal Zanovix.

## Files in this handoff

```
design_handoff_zanovix_crm/
├── README.md                          ← este archivo
├── crm.html                           ← entry point del prototipo
├── src/
│   ├── i18n.jsx                       ← strings ES / EN (todas las claves)
│   ├── data.jsx                       ← datos mock + helpers (fmtMoney, fmtDate, lookups)
│   ├── ui.jsx                         ← componentes compartidos (Icon, Btn, Table, KPI…)
│   ├── shell.jsx                      ← Sidebar + Topbar + AppShell
│   ├── internal-pages.jsx             ← Dashboard, Pipeline, Clients, Client 360
│   ├── internal-pages-2.jsx           ← Service detail, Billing, Calendar, Team
│   ├── portal-pages.jsx               ← todas las vistas del portal cliente
│   └── tweaks-panel.jsx               ← (panel de tweaks del prototipo, eliminar en prod)
└── assets/
    ├── founder-pepe.webp              ← foto del fundador
    └── zanovix-flower.png             ← logo (flor)
```

## Implementation order (sugerido)

1. **Auth + multi-tenant skeleton** (Supabase + middleware de rol)
2. **Modelo de datos + Prisma migrations**
3. **Sistema de componentes base** (tokens, tipografía, Tailwind config, shadcn/ui overrides para flat editorial look)
4. **Shell** (Sidebar + Topbar + i18n)
5. **Lado interno**: Clientes → Cliente 360 → Pipeline → Dashboard → Servicios → Facturación → Calendario → Equipo
6. **Portal cliente**: Dashboard → Servicios → Diagnóstico → Facturas → Documentos → Mensajes → Soporte → Reuniones
7. **Integraciones**: Stripe → Google Calendar → Google Drive

## Notas finales

- El prototipo ejecuta React via Babel en el navegador — **no es ese el patrón de producción**. Es solo para iterar diseño rápido.
- Todos los strings están aislados en `src/i18n.jsx` — copiar tal cual a `messages/es.json` y `messages/en.json` para `next-intl`.
- La marca utiliza una flor SVG inline (ver `#flower-defs` en `crm.html`). Para producción, exportar a archivo SVG limpio.
